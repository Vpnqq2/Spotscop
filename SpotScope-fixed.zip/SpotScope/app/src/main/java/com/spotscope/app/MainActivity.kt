package com.spotscope.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = BgC, surface = CardC, onSurface = TextC, onBackground = TextC)) { App() }
        }
    }
}

@Composable
fun App(vm: MainViewModel = viewModel()) {
    var splash by rememberSaveable { mutableStateOf(true) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var sub by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(Unit) { delay(1300); splash = false }
    if (splash) { SplashScreen(); return }

    fun open(sym: String) { vm.analyze(sym); tab = 2; sub = "" }
    BackHandler(enabled = sub != "" || tab != 0) { if (sub != "") sub = "" else tab = 0 }

    Column(Modifier.fillMaxSize().background(BgC)) {
        Box(Modifier.weight(1f)) {
            when (sub) {
                "discover" -> DiscoverScreen({ sub = "" }) { open(it) }
                "history" -> HistoryScreen({ sub = "" }) { open(it) }
                "settings" -> SettingsScreen { sub = "" }
                else -> when (tab) {
                    0 -> HomeScreen({ open(it) }) { sub = "discover" }
                    1 -> MarketsScreen({ open(it) }) { sub = "discover" }
                    2 -> AnalyzeScreen(vm) { open(it) }
                    3 -> FavoritesScreen { open(it) }
                    else -> MoreScreen { sub = it }
                }
            }
        }
        BottomBar(tab) { tab = it; sub = "" }
    }
}

@Composable
fun BottomBar(sel: Int, onSel: (Int) -> Unit) {
    val items = listOf<Pair<ImageVector, String>>(Icons.Filled.Home to "Home", Icons.Filled.List to "Markets", Icons.Filled.Search to "Analyze", Icons.Filled.Star to "Favorites", Icons.Filled.Menu to "More")
    Row(Modifier.fillMaxWidth().background(CardC).padding(vertical = 8.dp)) {
        items.forEachIndexed { i, (icon, label) ->
            Column(Modifier.weight(1f).clickable { onSel(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, contentDescription = label, tint = if (sel == i) Gold else MutedC)
                Text(label, color = if (sel == i) Gold else MutedC, fontSize = 10.sp)
            }
        }
    }
}
