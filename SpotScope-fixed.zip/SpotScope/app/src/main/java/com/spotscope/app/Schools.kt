package com.spotscope.app

import java.util.Locale
import kotlin.math.*

/** Each "school" returns a score in [-100, 100]. */
object Schools {
    private fun neutral(name: String, why: String, w: Double) = SchoolResult(name, 0.0, why, w)
    private fun f(fmt: String, vararg a: Any) = String.format(Locale.US, fmt, *a)

    fun trend(cs: List<Candle>): SchoolResult {
        val c = cs.map { it.c }; val n = c.size - 1; val p = c[n]
        val e20 = Ind.ema(c, 20); val e50 = Ind.ema(c, 50); val e200 = Ind.ema(c, 200)
        val back = max(0, n - 10)
        var s = 0.0
        s += if (p > e20[n]) 12.0 else -12.0
        s += if (p > e50[n]) 15.0 else -15.0
        s += if (p > e200[n]) 20.0 else -20.0
        s += if (e20[n] > e50[n]) 12.0 else -12.0
        s += if (e50[n] > e200[n]) 16.0 else -16.0
        s += if (e50[n] > e50[back]) 12.0 else -12.0
        s += if (e20[n] > e20[back]) 8.0 else -8.0
        val above = listOf(p > e20[n], p > e50[n], p > e200[n]).count { it }
        return SchoolResult("Trend (EMA 20/50/200)", clamp(s), "Price above $above/3 key EMAs", 1.5)
    }

    fun momentum(cs: List<Candle>): SchoolResult {
        val c = cs.map { it.c }
        val r = Ind.rsi(c).last(); val h = Ind.macdHist(c); val n = h.size - 1
        var s = 0.0
        s += if (h[n] > 0) 25.0 else -25.0
        s += if (h[n] > h[n - 1]) 15.0 else -15.0
        s += when { r in 50.0..70.0 -> 25.0; r > 70 -> -10.0; r >= 30 -> -20.0; else -> 10.0 }
        return SchoolResult("Momentum (RSI/MACD)", clamp(s * 1.5), f("RSI %.0f, MACD %s", r, if (h[n] > h[n - 1]) "rising" else "falling"), 1.0)
    }

    fun structure(cs: List<Candle>): SchoolResult {
        val sw = Ind.swings(cs)
        val hs = sw.filter { it.high }.takeLast(2); val ls = sw.filter { !it.high }.takeLast(2)
        if (hs.size < 2 || ls.size < 2) return neutral("Market Structure", "Not enough swings", 1.5)
        val hh = hs[1].p > hs[0].p; val hl = ls[1].p > ls[0].p
        var s = when { hh && hl -> 70.0; !hh && !hl -> -70.0; else -> 0.0 }
        var note = when { hh && hl -> "Higher highs & higher lows"; !hh && !hl -> "Lower highs & lower lows"; else -> "Mixed structure" }
        val p = cs.last().c
        if (p > hs[1].p) { s += 25; note += ", broke last swing high" }
        if (p < ls[1].p) { s -= 25; note += ", broke last swing low" }
        return SchoolResult("Market Structure (Price Action)", clamp(s), note, 1.5)
    }

    fun fib(cs: List<Candle>): SchoolResult {
        val sw = Ind.swings(cs)
        if (sw.size < 2) return neutral("Fibonacci", "No clear swing leg", 0.7)
        val last = sw.last(); val prev = sw.lastOrNull { it.high != last.high } ?: return neutral("Fibonacci", "No clear swing leg", 0.7)
        val p = cs.last().c
        if (abs(last.p - prev.p) < 1e-12) return neutral("Fibonacci", "No clear swing leg", 0.7)
        return if (last.high) {
            val lo = prev.p; val hi = last.p; val ret = (hi - p) / (hi - lo)
            val s = when { ret < 0 -> 40.0; ret < 0.236 -> 25.0; ret < 0.382 -> 45.0; ret < 0.5 -> 55.0; ret < 0.618 -> 70.0; ret < 0.786 -> 30.0; ret <= 1 -> -20.0; else -> -70.0 }
            SchoolResult("Fibonacci", s, f("Up-leg retrace %.1f%%", ret * 100), 0.7)
        } else {
            val hi = prev.p; val lo = last.p; val b = (p - lo) / (hi - lo)
            val s = when { b < 0 -> -60.0; b < 0.382 -> -35.0; b < 0.618 -> -25.0; b < 1 -> 10.0; else -> 50.0 }
            SchoolResult("Fibonacci", s, f("Bounce %.1f%% of down-leg", b * 100), 0.7)
        }
    }

    fun volume(cs: List<Candle>): SchoolResult {
        val n = cs.size
        if (n < 50) return neutral("Volume (OBV/VWAP)", "Not enough data", 1.0)
        val obv = Ind.obv(cs); val v20 = cs.takeLast(20).sumOf { it.v }
        val r = if (v20 > 0) (obv[n - 1] - obv[n - 21]) / v20 else 0.0
        var s = clamp(r * 100, -40.0, 40.0)
        val w = cs.takeLast(50)
        val vwap = w.sumOf { (it.h + it.l + it.c) / 3 * it.v } / max(1e-12, w.sumOf { it.v })
        s += if (cs.last().c > vwap) 20.0 else -20.0
        val avg = cs.takeLast(23).take(20).sumOf { it.v } / 20
        val rec = cs.takeLast(3).sumOf { it.v } / 3
        if (rec > 1.5 * avg) s += if (cs.takeLast(3).sumOf { it.c - it.o } > 0) 20.0 else -20.0
        return SchoolResult("Volume (OBV/VWAP)", clamp(s), "OBV ${if (r > 0) "rising" else "falling"}, price ${if (cs.last().c > vwap) "above" else "below"} VWAP", 1.0)
    }

    fun ichimoku(cs: List<Candle>): SchoolResult {
        val i = cs.size - 1
        if (i < 78) return neutral("Ichimoku", "Not enough data", 1.0)
        fun mid(ix: Int, n: Int): Double { val w = cs.subList(ix - n + 1, ix + 1); return (w.maxOf { it.h } + w.minOf { it.l }) / 2 }
        val tenkan = mid(i, 9); val kijun = mid(i, 26); val j = i - 26
        val a = (mid(j, 9) + mid(j, 26)) / 2; val b = mid(j, 52)
        val top = max(a, b); val bot = min(a, b); val p = cs[i].c
        var s = when { p > top -> 40.0; p < bot -> -40.0; else -> 0.0 }
        s += if (tenkan > kijun) 20.0 else -20.0
        s += if (p > kijun) 15.0 else -15.0
        s += if (a > b) 10.0 else -10.0
        val pos = when { p > top -> "above cloud"; p < bot -> "below cloud"; else -> "inside cloud" }
        return SchoolResult("Ichimoku", clamp(s), "Price $pos, Tenkan ${if (tenkan > kijun) ">" else "<"} Kijun", 1.0)
    }

    fun smc(cs: List<Candle>): SchoolResult {
        val atr = Ind.atr(cs); val p = cs.last().c; val m = Smc.of(cs)
        fun prox(d: Double) = clamp(1 - d / (3 * atr), 0.0, 1.0)
        val dd = m.demand.minOfOrNull { if (p in it[0]..it[1]) 0.0 else if (p > it[1]) p - it[1] else Double.MAX_VALUE }
        val sd = m.supply.minOfOrNull { if (p in it[0]..it[1]) 0.0 else if (p < it[0]) it[0] - p else Double.MAX_VALUE }
        val fd = m.fvgBull.minOfOrNull { if (p in it[0]..it[1]) 0.0 else if (p > it[1]) p - it[1] else Double.MAX_VALUE }
        val fs = m.fvgBear.minOfOrNull { if (p in it[0]..it[1]) 0.0 else if (p < it[0]) it[0] - p else Double.MAX_VALUE }
        val pd = if (dd == null) 0.0 else prox(dd); val ps = if (sd == null) 0.0 else prox(sd)
        val fpd = if (fd == null) 0.0 else prox(fd); val fps = if (fs == null) 0.0 else prox(fs)
        val s = 60 * pd - 60 * ps + 20 * fpd - 20 * fps
        val note = when { pd > ps && pd > 0 -> "Near demand order block"; ps > pd && ps > 0 -> "Near supply order block"; else -> "No active order block nearby" }
        return SchoolResult("Smart Money (OB/FVG)", clamp(s), note, 0.9)
    }

    fun patterns(cs: List<Candle>): SchoolResult {
        val a = cs[cs.size - 2]; val b = cs.last()
        val body = abs(b.c - b.o); val range = b.h - b.l
        val lw = min(b.o, b.c) - b.l; val uw = b.h - max(b.o, b.c)
        val bull = a.c < a.o && b.c > b.o && b.c >= a.o && b.o <= a.c
        val bear = a.c > a.o && b.c < b.o && b.c <= a.o && b.o >= a.c
        val hammer = range > 0 && lw > 2 * body && uw <= body
        val star = range > 0 && uw > 2 * body && lw <= body
        val (s, nt) = when { bull -> 50.0 to "Bullish engulfing"; bear -> -50.0 to "Bearish engulfing"; hammer -> 35.0 to "Hammer"; star -> -35.0 to "Shooting star"; else -> 0.0 to "No notable candle pattern" }
        return SchoolResult("Candlestick Patterns", s, nt, 0.3)
    }

    fun wyckoff(cs: List<Candle>): SchoolResult {
        if (cs.size < 60) return neutral("Wyckoff (Accum/Dist)", "Not enough data", 0.6)
        val w = cs.takeLast(60); val hi = w.maxOf { it.h }; val lo = w.minOf { it.l }; val atr = Ind.atr(cs)
        if (hi - lo > 10 * atr) return neutral("Wyckoff (Accum/Dist)", "Trending, no clear range", 0.6)
        val obv = Ind.obv(cs); val v = cs.takeLast(40).sumOf { it.v }
        val r = if (v > 0) (obv.last() - obv[obv.size - 40]) / v else 0.0
        return SchoolResult("Wyckoff (Accum/Dist)", clamp(r * 120, -60.0, 60.0), if (r > 0) "Range with accumulation (OBV rising)" else "Range with distribution (OBV falling)", 0.6)
    }
}
