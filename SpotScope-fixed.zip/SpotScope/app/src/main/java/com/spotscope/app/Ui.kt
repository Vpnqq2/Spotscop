package com.spotscope.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.*

val BgC = Color(0xFF0B0F14); val CardC = Color(0xFF131A23); val BorderC = Color(0xFF1F2835)
val Gold = Color(0xFFF0B90B); val GreenC = Color(0xFF2EBD85); val RedC = Color(0xFFF6465D); val OrangeC = Color(0xFFFF8A3D)
val TextC = Color(0xFFEAECEF); val MutedC = Color(0xFF848E9C); val BlueC = Color(0xFF5B8DEF)

fun scoreColor(s: Int) = when (s) { 5, 4 -> GreenC; 3 -> Gold; 2 -> OrangeC; else -> RedC }
fun signColor(x: Double) = if (x > 10) GreenC else if (x < -10) RedC else MutedC
fun regimeColor(n: String) = when (n) { "Bullish" -> GreenC; "Bearish" -> RedC; else -> Gold }
fun verdict(score: Int) = if (score >= 4) "Strong" else if (score == 3) "Neutral" else "Avoid"
fun fmtPrice(p: Double) = String.format(Locale.US, when { p >= 1000 -> "%,.2f"; p >= 1 -> "%.4f"; p >= 0.01 -> "%.5f"; else -> "%.8f" }, p)
fun fmtPct(x: Double) = String.format(Locale.US, "%+.2f%%", x)
fun fmtBig(x: Double) = when {
    x >= 1e12 -> String.format(Locale.US, "\$%.2fT", x / 1e12)
    x >= 1e9 -> String.format(Locale.US, "\$%.2fB", x / 1e9)
    else -> String.format(Locale.US, "\$%.1fM", x / 1e6)
}
fun baseOf(sym: String) = sym.removeSuffix("USDT")

@Composable
fun Panel(title: String? = null, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (title != null) Text(title, color = TextC, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        content()
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text, color = if (selected) Color.Black else MutedC, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (selected) Gold else CardC)
            .border(1.dp, if (selected) Gold else BorderC, RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
fun Avatar(sym: String, dia: Dp = 36.dp) {
    val b = baseOf(sym); val hue = ((b.hashCode() and 0x7fffffff) % 360).toFloat()
    Box(Modifier.size(dia).clip(CircleShape).background(Color.hsv(hue, 0.55f, 0.72f)), contentAlignment = Alignment.Center) {
        Text(b.take(2), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (dia.value * 0.36f).sp)
    }
}

@Composable
fun Ring(frac: Float, text: String, color: Color, dia: Dp, sub: String? = null) {
    Box(Modifier.size(dia), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = this.size.minDimension * 0.10f
            val inset = sw / 2
            val arcSize = Size(this.size.width - sw, this.size.height - sw)
            drawArc(color.copy(alpha = 0.18f), -90f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(sw))
            drawArc(color, -90f, 360f * frac.coerceIn(0f, 1f), false, Offset(inset, inset), arcSize, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text, color = color, fontWeight = FontWeight.ExtraBold, fontSize = (dia.value * 0.30f).sp)
            if (sub != null) Text(sub, color = MutedC, fontSize = (dia.value * 0.13f).sp)
        }
    }
}

@Composable
fun ScoreRing(score: Int?, dia: Dp = 34.dp) =
    Ring((score ?: 0) / 5f, score?.toString() ?: "–", if (score == null) MutedC else scoreColor(score), dia)

@Composable
fun Sparkline(v: List<Double>, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (v.size < 2) return@Canvas
        val mn = v.min(); val mx = v.max(); val rg = max(mx - mn, 1e-12)
        val path = Path()
        v.forEachIndexed { i, x ->
            val px = this.size.width * i / (v.size - 1)
            val py = this.size.height * (1 - (x - mn) / rg).toFloat()
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        drawPath(path, color, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun CoinRow(sym: String, price: Double?, change: Double?, score: Int?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Avatar(sym)
        Column(Modifier.weight(1f)) {
            Text(baseOf(sym), color = TextC, fontWeight = FontWeight.Bold)
            Text("Spot · USDT", color = MutedC, fontSize = 11.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(if (price != null) fmtPrice(price) else "–", color = TextC, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            if (change != null) Text(fmtPct(change), color = if (change >= 0) GreenC else RedC, fontSize = 12.sp)
        }
        ScoreRing(score, 38.dp)
    }
}

// ------------------------------------------------------------------ charts

@Composable
fun CandleChart(cs: List<Candle>, e20: List<Double>, e50: List<Double>, zones: List<Zone>, lines: List<Pair<Double, Color>>, modifier: Modifier) {
    val tm = rememberTextMeasurer()
    Canvas(modifier) {
        val n = cs.size
        if (n < 2) return@Canvas
        val w = this.size.width - 52.dp.toPx(); val h = this.size.height
        var mx = cs.maxOf { it.h }; var mn = cs.minOf { it.l }
        val pad = (mx - mn) * 0.05; mx += pad; mn -= pad
        fun y(p: Double) = (h * (1 - (p - mn) / (mx - mn))).toFloat()
        val lbl = TextStyle(color = MutedC, fontSize = 9.sp)
        for (i in 0..4) {
            val p = mn + (mx - mn) * i / 4; val yy = y(p)
            drawLine(BorderC, Offset(0f, yy), Offset(w, yy), 1f)
            drawText(tm, fmtPrice(p), Offset(w + 4.dp.toPx(), yy - 6.dp.toPx()), lbl)
        }
        zones.forEach { z ->
            val t = max(y(z.high), 0f); val b = min(y(z.low), h)
            if (b > t) drawRect(GreenC.copy(alpha = 0.15f), Offset(0f, t), Size(w, b - t))
        }
        lines.forEach { (p, c) ->
            if (p in mn..mx) drawLine(c, Offset(0f, y(p)), Offset(w, y(p)), 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
        }
        val cw = w / n
        cs.forEachIndexed { i, c ->
            val x = cw * i + cw / 2; val col = if (c.c >= c.o) GreenC else RedC
            drawLine(col, Offset(x, y(c.h)), Offset(x, y(c.l)), 1f)
            val top = y(max(c.o, c.c)); val bot = y(min(c.o, c.c))
            drawRect(col, Offset(x - cw * 0.35f, top), Size(cw * 0.7f, max(bot - top, 1f)))
        }
        fun line(v: List<Double>, col: Color) {
            val p = Path()
            v.forEachIndexed { i, x -> val px = cw * i + cw / 2; if (i == 0) p.moveTo(px, y(x)) else p.lineTo(px, y(x)) }
            drawPath(p, col, style = Stroke(1.5f))
        }
        line(e20, Gold); line(e50, BlueC)
        val last = cs.last().c
        drawLine(MutedC.copy(alpha = 0.6f), Offset(0f, y(last)), Offset(w, y(last)), 1f)
        drawText(tm, fmtPrice(last), Offset(w + 4.dp.toPx(), y(last) - 6.dp.toPx()),
            TextStyle(color = Color.Black, background = if (last >= cs.last().o) GreenC else RedC, fontSize = 9.sp))
    }
}

@Composable
fun IndicatorPanel(kind: String, all: List<Candle>, n: Int, modifier: Modifier) {
    val closes = remember(all) { all.map { it.c } }
    val rsi = remember(all) { Ind.rsi(closes).takeLast(n) }
    val hist = remember(all) { Ind.macdHist(closes).takeLast(n) }
    val vis = all.takeLast(n)
    val tm = rememberTextMeasurer()
    Canvas(modifier) {
        if (vis.size < 2) return@Canvas
        val w = this.size.width - 52.dp.toPx(); val h = this.size.height; val cw = w / n
        val lbl = TextStyle(color = MutedC, fontSize = 9.sp)
        when (kind) {
            "RSI" -> {
                fun y(v: Double) = (h * (1 - v / 100)).toFloat()
                listOf(30.0, 70.0).forEach { drawLine(BorderC, Offset(0f, y(it)), Offset(w, y(it)), 1f); drawText(tm, it.toInt().toString(), Offset(w + 4.dp.toPx(), y(it) - 6.dp.toPx()), lbl) }
                val p = Path()
                rsi.forEachIndexed { i, v -> val px = cw * i + cw / 2; if (i == 0) p.moveTo(px, y(v)) else p.lineTo(px, y(v)) }
                drawPath(p, Color(0xFFB57CFF), style = Stroke(2f))
                drawText(tm, String.format(Locale.US, "%.0f", rsi.last()), Offset(w + 4.dp.toPx(), y(rsi.last()) - 6.dp.toPx()), TextStyle(color = Color(0xFFB57CFF), fontSize = 10.sp))
            }
            "MACD" -> {
                val m = max(hist.maxOf { abs(it) }, 1e-12)
                drawLine(BorderC, Offset(0f, h / 2), Offset(w, h / 2), 1f)
                hist.forEachIndexed { i, v ->
                    val bh = (abs(v) / m * (h / 2)).toFloat()
                    drawRect(if (v >= 0) GreenC else RedC, Offset(cw * i + cw * 0.15f, if (v >= 0) h / 2 - bh else h / 2), Size(cw * 0.7f, max(bh, 1f)))
                }
            }
            else -> {
                val m = max(vis.maxOf { it.v }, 1e-12)
                vis.forEachIndexed { i, c ->
                    val bh = (c.v / m * h).toFloat()
                    drawRect((if (c.c >= c.o) GreenC else RedC).copy(alpha = 0.8f), Offset(cw * i + cw * 0.15f, h - bh), Size(cw * 0.7f, max(bh, 1f)))
                }
            }
        }
    }
}
