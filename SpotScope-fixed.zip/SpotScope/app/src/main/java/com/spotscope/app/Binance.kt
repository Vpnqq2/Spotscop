package com.spotscope.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

data class Ticker(val last: Double, val changePct: Double, val quoteVolume: Double)

/** Public, read-only Binance spot market data. No API key needed. */
object Binance {
    private val bases = listOf("https://data-api.binance.vision", "https://api.binance.com", "https://api1.binance.com", "https://api3.binance.com")

    private fun get(path: String): String {
        var last: Exception? = null
        for (b in bases) {
            try {
                val c = URL(b + path).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 12000
                c.setRequestProperty("User-Agent", "SpotScope/1.0")
                val code = c.responseCode
                if (code == 200) return c.inputStream.bufferedReader().use { it.readText() }
                if (code == 400) throw SymbolNotFound()
                last = IOException("HTTP $code")
            } catch (e: SymbolNotFound) { throw e } catch (e: Exception) { last = e }
        }
        throw last ?: IOException("Network error")
    }

    fun normalize(input: String): String {
        val t = input.uppercase().replace(Regex("[^A-Z0-9]"), "")
        if (t.isEmpty()) throw SymbolNotFound()
        return if (t.endsWith("USDT")) t else t + "USDT"
    }

    suspend fun ticker(sym: String): Ticker = withContext(Dispatchers.IO) {
        val o = JSONObject(get("/api/v3/ticker/24hr?symbol=$sym"))
        Ticker(o.getString("lastPrice").toDouble(), o.getString("priceChangePercent").toDouble(), o.getString("quoteVolume").toDouble())
    }

    suspend fun klines(sym: String, interval: String, limit: Int): List<Candle> = withContext(Dispatchers.IO) {
        val a = JSONArray(get("/api/v3/klines?symbol=$sym&interval=$interval&limit=$limit"))
        (0 until a.length()).map {
            val k = a.getJSONArray(it)
            Candle(k.getLong(0), k.getString(1).toDouble(), k.getString(2).toDouble(), k.getString(3).toDouble(), k.getString(4).toDouble(), k.getString(5).toDouble())
        }
    }

    /** Bid/ask imbalance within 3% of price, in [-1, 1]. */
    suspend fun orderBookImbalance(sym: String, price: Double): Double = withContext(Dispatchers.IO) {
        val o = JSONObject(get("/api/v3/depth?symbol=$sym&limit=500"))
        fun side(k: String) = o.getJSONArray(k).let { a ->
            (0 until a.length()).sumOf { i ->
                val r = a.getJSONArray(i); val p = r.getString(0).toDouble()
                if (abs(p - price) / price <= 0.03) p * r.getString(1).toDouble() else 0.0
            }
        }
        val b = side("bids"); val s = side("asks")
        if (b + s == 0.0) 0.0 else (b - s) / (b + s)
    }

    suspend fun allTickers(): List<Pair<String, Ticker>> = withContext(Dispatchers.IO) {
        val a = JSONArray(get("/api/v3/ticker/24hr"))
        (0 until a.length()).mapNotNull {
            val o = a.getJSONObject(it)
            runCatching { o.getString("symbol") to Ticker(o.getString("lastPrice").toDouble(), o.getString("priceChangePercent").toDouble(), o.getString("quoteVolume").toDouble()) }.getOrNull()
        }
    }
}
