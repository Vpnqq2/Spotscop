package com.spotscope.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

// ------------------------------------------------------------------ shared pieces
@Composable
fun Screen(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
fun Title(t: String, onBack: (() -> Unit)? = null, leading: @Composable (() -> Unit)? = null, trailing: @Composable (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) Text("‹", color = Gold, fontSize = 32.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 14.dp))
        if (leading != null) { leading(); Spacer(Modifier.width(10.dp)) }
        Text(t, color = TextC, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing?.invoke()
    }
}

@Composable
fun SearchBox(onGo: (String) -> Unit, autoFocus: Boolean = false) {
    var q by rememberSaveable { mutableStateOf("") }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (autoFocus) runCatching { fr.requestFocus() } }
    OutlinedTextField(
        value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth().focusRequester(fr), singleLine = true, shape = RoundedCornerShape(26.dp),
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = MutedC) },
        trailingIcon = { if (q.isNotBlank()) Text(tr("تحليل", "Go"), color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onGo(q) }.padding(end = 16.dp)) },
        placeholder = { Text("Search coin (BTC, ETH, AVAX...)", color = MutedC, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = BorderC, focusedTextColor = TextC, unfocusedTextColor = TextC, cursorColor = Gold, focusedContainerColor = CardC, unfocusedContainerColor = CardC),
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { if (q.isNotBlank()) onGo(q) })
    )
}

@Composable
fun ScanStatus() {
    if (Scanner.running) Text(tr("جارٍ تقييم أهم العملات… ${Scanner.done}/${Scanner.total}", "Scoring top coins… ${Scanner.done}/${Scanner.total}"), color = MutedC, fontSize = 12.sp)
}

@Composable
fun rememberSparks(syms: List<String>): Map<String, List<Double>> {
    val m = remember { mutableStateMapOf<String, List<Double>>() }
    LaunchedEffect(syms.joinToString(",")) {
        syms.filter { it !in m }.forEach { s -> launch { m[s] = runCatching { MarketData.spark(s) }.getOrDefault(emptyList()) } }
    }
    return m
}

@Composable
fun CoinRow(sym: String, price: Double?, change: Double?, strength: Int?, spark: List<Double>?, showBtn: Boolean = true, onClick: () -> Unit) {
    val up = (change ?: 0.0) >= 0
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        CoinLogo(sym, 36.dp)
        Column(Modifier.weight(1f)) {
            Text(baseOf(sym), color = TextC, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (!showBtn) Text(coinName(sym), color = MutedC, fontSize = 11.sp)
            Text(if (price != null) fmtUsd(price) else "–", color = TextC, fontSize = 12.sp)
            if (change != null) Text(fmtPct(change), color = if (up) GreenC else RedC, fontSize = 11.sp)
        }
        if (spark != null) Sparkline(spark, if (up) GreenC else RedC, Modifier.width(56.dp).height(28.dp))
        if (showBtn) MiniBtn(tr("تحليل", "Analyze"), onClick = onClick)
        ScoreRing(strength, 36.dp)
    }
}

@Composable
fun MiniRow(s: ScanItem, onOpen: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onOpen(s.sym) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CoinLogo(s.sym, 28.dp)
        Text(baseOf(s.sym), color = TextC, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(fmtPct(s.change), color = if (s.change >= 0) GreenC else RedC, fontSize = 12.sp)
        ScoreRing(s.strength, 30.dp)
    }
}

@Composable
fun Mover(t: Tick, onOpen: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onOpen(t.sym) }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        CoinLogo(t.sym, 22.dp)
        Text(baseOf(t.sym), color = TextC, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(fmtPct(t.change), color = if (t.change >= 0) GreenC else RedC, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ------------------------------------------------------------------ SPLASH
@Composable
fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0C1424), BgC)))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width; val h = this.size.height
            drawCircle(Brush.radialGradient(listOf(Gold.copy(alpha = 0.20f), Color.Transparent), center = Offset(w / 2, h * 0.30f), radius = w * 0.8f), radius = w * 0.8f, center = Offset(w / 2, h * 0.30f))
            fun wave(y0: Float, amp: Float, a: Float, sw: Float) {
                val p = Path()
                p.moveTo(0f, h * y0)
                p.cubicTo(w * 0.25f, h * (y0 - amp), w * 0.5f, h * (y0 + amp), w * 0.75f, h * (y0 - amp * 0.4f))
                p.cubicTo(w * 0.85f, h * (y0 - amp * 0.7f), w * 0.95f, h * (y0 + amp * 0.2f), w, h * (y0 - amp * 0.5f))
                drawPath(p, Gold.copy(alpha = a), style = Stroke(sw, cap = StrokeCap.Round))
            }
            wave(0.72f, 0.07f, 0.55f, 3f); wave(0.75f, 0.08f, 0.30f, 2f); wave(0.78f, 0.05f, 0.18f, 1.5f)
        }
        Column(Modifier.fillMaxSize().padding(top = 110.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            LogoMark(84.dp)
            Spacer(Modifier.height(14.dp))
            Text("SpotScope", color = Gold, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
            Text("Smart Spot Analysis", color = TextC, fontSize = 15.sp)
            Spacer(Modifier.height(18.dp))
            Text(tr("تحليل احترافي لأسواق العملات الرقمية بدون تعقيد", "Professional crypto spot analysis, no noise"), color = Gold.copy(alpha = 0.85f), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 40.dp))
        }
        Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp).size(300.dp, 170.dp)) {
            Box(Modifier.offset(x = 108.dp, y = 22.dp)) { CoinLogo("BTCUSDT", 86.dp) }
            Box(Modifier.offset(x = 200.dp, y = 40.dp)) { CoinLogo("ETHUSDT", 66.dp) }
            Box(Modifier.offset(x = 30.dp, y = 56.dp)) { CoinLogo("LINKUSDT", 56.dp) }
            Box(Modifier.offset(x = 92.dp, y = 112.dp)) { CoinLogo("SOLUSDT", 46.dp) }
            Box(Modifier.offset(x = 232.dp, y = 112.dp)) { CoinLogo("BNBUSDT", 48.dp) }
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(46.dp).height(6.dp).clip(CircleShape).background(Gold))
            Box(Modifier.size(6.dp).clip(CircleShape).background(MutedC.copy(alpha = 0.5f)))
            Box(Modifier.size(6.dp).clip(CircleShape).background(MutedC.copy(alpha = 0.5f)))
        }
    }
}

// ------------------------------------------------------------------ HOME
@Composable
fun HomeScreen(onOpen: (String) -> Unit, onDiscover: () -> Unit) {
    var ticks by remember { mutableStateOf<List<Tick>>(emptyList()) }
    var ov by remember { mutableStateOf<Overview?>(null) }
    LaunchedEffect(Unit) { Scanner.ensure() }
    LaunchedEffect(Unit) { ticks = runCatching { MarketData.tickers() }.getOrDefault(emptyList()) }
    LaunchedEffect(Unit) { ov = runCatching { MarketData.overview() }.getOrNull() }
    val top = ticks.sortedByDescending { it.quoteVol }.take(5)
    val sparks = rememberSparks(listOf("BTCUSDT", "ETHUSDT") + top.map { it.sym })
    var showSearch by rememberSaveable { mutableStateOf(false) }
    Screen {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LogoMark(30.dp)
            Spacer(Modifier.width(8.dp))
            Text("SpotScope", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            Box(Modifier.size(40.dp).clip(CircleShape).clickable { showSearch = !showSearch }, contentAlignment = Alignment.Center) {
                if (showSearch) Text("✕", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                else Icon(Icons.Filled.Search, contentDescription = "Search", tint = Gold)
            }
        }
        if (showSearch) SearchBox({ showSearch = false; onOpen(it) }, autoFocus = true)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("BTCUSDT", "ETHUSDT").forEach { s ->
                val t = ticks.firstOrNull { it.sym == s }
                val up = (t?.change ?: 0.0) >= 0
                Panel(modifier = Modifier.weight(1f).clickable { onOpen(s) }) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { CoinLogo(s, 30.dp); Text(baseOf(s), color = TextC, fontWeight = FontWeight.Bold) }
                    Text(t?.let { fmtUsd(it.last) } ?: "–", color = TextC, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(t?.let { fmtPct(it.change) } ?: "", color = if (up) GreenC else RedC, fontSize = 12.sp)
                    Sparkline(sparks[s] ?: emptyList(), if (up) GreenC else RedC, Modifier.fillMaxWidth().height(34.dp))
                }
            }
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Market Overview", color = Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Text("Spot Market", color = MutedC, fontSize = 10.sp, modifier = Modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, BorderC, RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(0, 1).forEach { k ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(CardHi).border(1.dp, BorderC, RoundedCornerShape(12.dp)).padding(10.dp)) {
                        Text(if (k == 0) "Total Market Cap" else "BTC Dominance", color = MutedC, fontSize = 10.sp)
                        if (k == 0) {
                            Text(ov?.totalCap?.let { fmtBig(it) } ?: "–", color = TextC, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            ov?.capChange?.takeIf { !it.isNaN() }?.let { Text(fmtPct(it), color = if (it >= 0) GreenC else RedC, fontSize = 11.sp) }
                        } else {
                            Text(ov?.btcDom?.let { String.format(Locale.US, "%.1f%%", it) } ?: "–", color = TextC, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        Sparkline(sparks["BTCUSDT"] ?: emptyList(), GreenC, Modifier.fillMaxWidth().height(24.dp))
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionTitle(tr("أهم العملات", "Top Coins"), Modifier.weight(1f))
            Text(tr("اكتشف ›", "Discover ›"), color = Gold, fontSize = 13.sp, modifier = Modifier.clickable(onClick = onDiscover))
        }
        ScanStatus()
        if (ticks.isEmpty()) Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
        top.forEach { t -> CoinRow(t.sym, t.last, t.change, Scanner.items[t.sym]?.strength, sparks[t.sym]) { onOpen(t.sym) } }
    }
}

// ------------------------------------------------------------------ MARKETS
@Composable
fun MarketsScreen(onOpen: (String) -> Unit, onDiscover: () -> Unit) {
    var reg by remember { mutableStateOf<Regime?>(null) }
    var ticks by remember { mutableStateOf<List<Tick>>(emptyList()) }
    var ov by remember { mutableStateOf<Overview?>(null) }
    LaunchedEffect(Unit) { Scanner.ensure() }
    LaunchedEffect(Unit) { reg = runCatching { Analyzer.regime() }.getOrNull() }
    LaunchedEffect(Unit) { ticks = runCatching { MarketData.tickers() }.getOrDefault(emptyList()) }
    LaunchedEffect(Unit) { ov = runCatching { MarketData.overview() }.getOrNull() }
    val sparks = rememberSparks(listOf("BTCUSDT"))
    val btc = ticks.firstOrNull { it.sym == "BTCUSDT" }
    val up = (btc?.change ?: 0.0) >= 0
    val ranked = Scanner.items.values.filter { it.sym != "BTCUSDT" }.sortedWith(compareByDescending<ScanItem> { it.score }.thenByDescending { it.strength })
    val movers = ticks.sortedByDescending { it.quoteVol }.take(60).sortedByDescending { it.change }
    val r = reg
    Screen {
        Title(tr("تحليل السوق", "Market Analysis"))
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("اتجاه البيتكوين العام", "Overall Bitcoin trend"), color = TextC, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                if (r != null) Text(tr("اتجاه ", "Trend ") + regimeText(r.name), color = regimeColor(r.name), fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(regimeColor(r.name).copy(alpha = 0.12f)).border(1.dp, regimeColor(r.name).copy(alpha = 0.5f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CoinLogo("BTCUSDT", 40.dp)
                Column {
                    Text("BTC", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(btc?.let { fmtUsd(it.last) } ?: "–", color = TextC, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
                Sparkline(sparks["BTCUSDT"] ?: emptyList(), if (up) GreenC else RedC, Modifier.weight(1f).height(44.dp))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Panel(modifier = Modifier.weight(1f)) {
                Text(tr("هيمنة البيتكوين", "BTC Dominance"), color = MutedC, fontSize = 11.sp)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text(ov?.btcDom?.let { String.format(Locale.US, "%.1f%%", it) } ?: "–", color = TextC, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Ring(((ov?.btcDom ?: 0.0) / 100).toFloat(), "", GreenC, 46.dp)
                }
            }
            Panel(modifier = Modifier.weight(1f)) {
                Text(tr("حالة السوق", "Market State"), color = MutedC, fontSize = 11.sp)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    if (r == null) CircularProgressIndicator(color = Gold, modifier = Modifier.size(24.dp))
                    else {
                        Text(regimeText(r.name), color = regimeColor(r.name), fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                        Text(if (r.name == "Bullish") "↗" else if (r.name == "Bearish") "↘" else "→", color = regimeColor(r.name), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        ScanStatus()
        Panel(tr("أقوى العملات البديلة", "Strongest Alts")) {
            if (ranked.isEmpty()) Text(tr("جارٍ التقييم…", "Scoring coins…"), color = MutedC, fontSize = 12.sp)
            ranked.take(5).forEach { MiniRow(it, onOpen) }
        }
        Panel(tr("أضعف العملات البديلة", "Weakest Alts")) { ranked.takeLast(3).reversed().forEach { MiniRow(it, onOpen) } }
        if (r != null) {
            val tip = when (r.name) {
                "Bullish" -> tr("الظروف الحالية مناسبة لتحليل العملات البديلة. فضّل العملات ذات التقييم المرتفع والدخول عند التراجعات.", "Conditions favour spot entries on pullbacks into the entry zones. Prefer coins scoring 4 or 5.")
                "Bearish" -> tr("البيتكوين ضعيف، لذا تحمل العملات البديلة مخاطرة إضافية. قلّل حجم الصفقات أو انتظر سوقاً أفضل.", "BTC is weak, so altcoins carry extra risk. Reduce size, or wait for a better market.")
                else -> tr("السوق غير محسوم. كن انتقائياً ولا تدخل إلا في الفرص القوية.", "Market is undecided. Be selective and only take setups scoring 4 or higher.")
            }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Brush.horizontalGradient(listOf(Gold.copy(alpha = 0.20f), Gold.copy(alpha = 0.06f)))).border(1.dp, Gold.copy(alpha = 0.45f), RoundedCornerShape(16.dp)).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NavIcon("markets", Gold, 30.dp)
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(tr("ملاحظة ظروف السوق", "Market conditions note"), color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(tip, color = TextC, fontSize = 12.sp)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Panel(tr("الأكثر ربحاً 24س", "Top Gainers 24h"), Modifier.weight(1f)) { movers.take(3).forEach { Mover(it, onOpen) } }
            Panel(tr("الأكثر خسارة 24س", "Top Losers 24h"), Modifier.weight(1f)) { movers.takeLast(3).reversed().forEach { Mover(it, onOpen) } }
        }
        Text(tr("تصفح كل العملات المقيّمة ›", "Browse all scored coins ›"), color = Gold, modifier = Modifier.clickable(onClick = onDiscover))
    }
}

// ------------------------------------------------------------------ DISCOVER
@Composable
fun DiscoverScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    var f by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { Scanner.ensure() }
    val all = Scanner.items.values.sortedWith(compareByDescending<ScanItem> { it.score }.thenByDescending { it.strength })
    val list = when (f) { 1 -> all.filter { it.score >= 4 }; 2 -> all.sortedByDescending { it.change }; 3 -> all.filter { it.score <= 2 }; else -> all }
    Screen {
        Title(tr("اكتشاف العملات", "Discover Coins"), onBack) { Icon(Icons.Filled.Refresh, contentDescription = null, tint = MutedC, modifier = Modifier.clickable { Scanner.ensure(true) }) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(tr("الكل", "All"), tr("القوي", "Strong"), tr("الأكثر صعوداً", "Top gainers"), tr("تجنب", "Avoid")).forEachIndexed { i, t -> Chip(t, f == i, Modifier.weight(1f), 6.dp) { f = i } }
        }
        ScanStatus()
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Spacer(Modifier.width(18.dp))
            Text(tr("العملة", "Coin"), color = MutedC, fontSize = 10.sp, modifier = Modifier.weight(1f))
            Text(tr("السعر", "Price"), color = MutedC, fontSize = 10.sp, modifier = Modifier.weight(1.15f))
            Text("24h", color = MutedC, fontSize = 10.sp, modifier = Modifier.weight(0.9f))
            Text(tr("الإشارة", "Signal"), color = MutedC, fontSize = 10.sp, modifier = Modifier.width(34.dp), textAlign = TextAlign.Center)
            Text(tr("تحليل", "Analyze"), color = MutedC, fontSize = 10.sp, modifier = Modifier.width(44.dp), textAlign = TextAlign.Center)
        }
        if (list.isEmpty() && !Scanner.running) Text(tr("لا توجد عملات في هذه المجموعة حالياً.", "No coins in this group right now."), color = MutedC)
        list.forEachIndexed { i, s ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(14.dp)).clickable { onOpen(s.sym) }.padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text((i + 1).toString(), color = MutedC, fontSize = 11.sp, modifier = Modifier.width(18.dp))
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    CoinLogo(s.sym, 22.dp); Text(baseOf(s.sym), color = TextC, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
                Text(fmtUsd(s.price), color = TextC, fontSize = 11.sp, maxLines = 1, modifier = Modifier.weight(1.15f))
                Text(fmtPct(s.change), color = if (s.change >= 0) GreenC else RedC, fontSize = 11.sp, maxLines = 1, modifier = Modifier.weight(0.9f))
                Box(Modifier.width(34.dp), contentAlignment = Alignment.Center) { ScoreRing(s.strength, 32.dp) }
                MiniBtn(tr("تحليل", "Go"), Modifier.width(44.dp)) { onOpen(s.sym) }
            }
        }
    }
}

// ------------------------------------------------------------------ FAVORITES / HISTORY
@Composable
fun FavoritesScreen(onOpen: (String) -> Unit) {
    var ticks by remember { mutableStateOf<List<Tick>>(emptyList()) }
    LaunchedEffect(Unit) { ticks = runCatching { MarketData.tickers() }.getOrDefault(emptyList()); Scanner.ensure(Store.favorites.any { it !in Scanner.items }) }
    val favs = Store.favorites.toList()
    val sparks = rememberSparks(favs)
    Screen {
        Title(tr("المفضلة", "Favorites"), leading = { Icon(Icons.Filled.Star, contentDescription = null, tint = Gold, modifier = Modifier.size(28.dp)) })
        if (favs.isEmpty()) Text(tr("اضغط على النجمة في صفحة تحليل أي عملة لإضافتها هنا.", "Tap the star on a coin's analysis page to add it here."), color = MutedC)
        favs.forEach { s ->
            val t = ticks.firstOrNull { it.sym == s }
            CoinRow(s, t?.last, t?.change, Scanner.items[s]?.strength, sparks[s], showBtn = false) { onOpen(s) }
        }
    }
}

@Composable
fun HistoryScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    var f by remember { mutableStateOf(0) }
    val fmt = remember(Store.lang) { SimpleDateFormat("h:mm a · d MMM yyyy", if (Store.lang == "ar") Locale.forLanguageTag("ar-u-nu-latn") else Locale.US) }
    val list = Store.history.filter { when (f) { 1 -> it.score == 3; 2 -> it.score >= 4; 3 -> it.score <= 2; else -> true } }
    Screen {
        Title(tr("سجل التحليلات", "Analysis History"), onBack, leading = { NavIcon("history", Gold, 26.dp) })
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(tr("الكل", "All"), tr("انتظار", "Wait"), tr("شراء", "Buy"), tr("تجنب", "Avoid")).forEachIndexed { i, t -> Chip(t, f == i, Modifier.weight(1f), 6.dp) { f = i } }
        }
        if (list.isEmpty()) Text(tr("لا توجد تحليلات بعد.", "No analyses yet."), color = MutedC)
        list.forEach { h ->
            val st = if (h.strength > 0) h.strength else strengthOf(h.score, 50)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(14.dp)).clickable { onOpen(h.sym) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CoinLogo(h.sym, 38.dp)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(baseOf(h.sym), color = TextC, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(verdict(h.score), color = scoreColor(h.score), fontWeight = FontWeight.Bold, fontSize = 10.sp,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(scoreColor(h.score).copy(alpha = 0.14f)).border(1.dp, scoreColor(h.score).copy(alpha = 0.5f), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                    Text(fmtUsd(h.price), color = MutedC, fontSize = 12.sp)
                    Text(fmt.format(Date(h.time)), color = MutedC, fontSize = 10.sp)
                }
                ScoreRing(st, 38.dp)
            }
        }
    }
}

// ------------------------------------------------------------------ MORE / SETTINGS
@Composable
fun SettingRow(icon: @Composable () -> Unit, label: String, value: String? = null, chevron: Boolean = true, trailing: @Composable (() -> Unit)? = null, onClick: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        icon()
        Text(label, color = TextC, fontSize = 14.sp, modifier = Modifier.weight(1f))
        if (value != null) Text(value, color = MutedC, fontSize = 13.sp)
        trailing?.invoke()
        if (chevron) Text("›", color = MutedC, fontSize = 20.sp)
    }
}

@Composable
fun SettingsGroup(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(16.dp)), content = content)
}

@Composable
fun Sep() { Box(Modifier.fillMaxWidth().height(1.dp).background(BorderC)) }

@Composable
fun MoreScreen(go: (String) -> Unit) {
    var about by remember { mutableStateOf(false) }
    val tfLabel = TFS.firstOrNull { it.first == Store.defaultTf }?.second ?: Store.defaultTf
    Screen {
        Title(tr("الإعدادات", "Settings"), leading = { Icon(Icons.Filled.Settings, contentDescription = null, tint = Gold, modifier = Modifier.size(26.dp)) })
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(Gold), contentAlignment = Alignment.Center) { LogoMark(28.dp) }
            Column(Modifier.weight(1f)) {
                Text("SpotScope", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("Smart Spot Analysis", color = MutedC, fontSize = 12.sp)
            }
            Text("v1.0", color = MutedC, fontSize = 11.sp)
        }
        SettingsGroup {
            SettingRow({ Icon(Icons.Filled.Notifications, null, tint = MutedC) }, tr("الإشعارات", "Notifications"), chevron = false, trailing = {
                Switch(checked = Store.notif, onCheckedChange = { Store.changeNotif(it) }, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Gold, uncheckedThumbColor = MutedC, uncheckedTrackColor = CardHi, uncheckedBorderColor = BorderC))
            })
            Sep()
            SettingRow({ NavIcon("analyze", MutedC) }, tr("تحليل العملات", "Default timeframe"), tfLabel) {
                val i = TFS.indexOfFirst { it.first == Store.defaultTf }
                Store.setTf(TFS[(i + 1) % TFS.size].first)
            }
            Sep()
            SettingRow({ CircleGlyph("\$", MutedC) }, tr("العملة الافتراضية", "Default currency"), "USD", chevron = true)
            Sep()
            SettingRow({ NavIcon("globe", MutedC) }, tr("اللغة", "Language"), if (Store.lang == "ar") "العربية" else "English") { Store.changeLang(if (Store.lang == "ar") "en" else "ar") }
        }
        SettingsGroup {
            SettingRow({ NavIcon("markets", MutedC) }, tr("اكتشاف العملات", "Discover Coins")) { go("discover") }
            Sep()
            SettingRow({ NavIcon("history", MutedC) }, tr("سجل التحليلات", "Analysis History")) { go("history") }
            Sep()
            SettingRow({ CircleGlyph("?", MutedC) }, tr("المساعدة", "Help")) { about = !about }
            Sep()
            SettingRow({ CircleGlyph("i", MutedC) }, tr("حول التطبيق", "About")) { about = !about }
        }
        if (about) Panel {
            Text(tr("مصدر البيانات: Binance Spot (عام). القيمة السوقية وهيمنة البيتكوين: CoinGecko.", "Market data: Binance public spot API. Market cap and BTC dominance: CoinGecko."), color = MutedC, fontSize = 12.sp)
            Text(tr("هذا ليس نصيحة مالية. لا يوجد تحليل دقيق 100%. استخدم وقف الخسارة دائماً ولا تخاطر بأكثر مما تتحمل خسارته.", "Not financial advice. No analysis is 100% accurate. Always use a stop loss and never risk more than you can afford to lose."), color = MutedC, fontSize = 12.sp)
        }
        SettingsGroup {
            SettingRow({ Text("🗑", fontSize = 16.sp) }, tr("مسح سجل التحليلات", "Clear analysis history"), chevron = false) { Store.clearHistory() }
            Sep()
            SettingRow({ Text("🗑", fontSize = 16.sp) }, tr("مسح المفضلة", "Clear favorites"), chevron = false) { Store.clearFavorites() }
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Brush.horizontalGradient(listOf(Gold.copy(alpha = 0.22f), Gold.copy(alpha = 0.06f)))).border(1.dp, Gold.copy(alpha = 0.45f), RoundedCornerShape(16.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            LogoMark(40.dp)
            Column(Modifier.weight(1f)) {
                Text(tr("حلّل أذكى، قرارات أفضل", "Analyze smarter, decide better"), color = Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("SpotScope v1.0", color = MutedC, fontSize = 11.sp)
            }
        }
    }
}

val TFS = listOf("1m" to "1m", "5m" to "5m", "15m" to "15m", "1h" to "1h", "4h" to "4h", "1d" to "1D", "1w" to "1W")

// ------------------------------------------------------------------ ANALYZE
@Composable
fun AnalyzeScreen(vm: MainViewModel, onBack: () -> Unit, onSearch: (String) -> Unit) {
    val st = vm.state
    Screen {
        Title(tr("تحليل العملة", "Coin Analysis"), onBack)
        if (st !is UiState.Done) SearchBox(onSearch)
        when (st) {
            UiState.Idle -> {
                Text(tr("اكتب اسم عملة لتحصل على تقييمها ومناطق الدخول والأهداف ووقف الخسارة.", "Type a coin to get its score, entry zones, targets and stop loss."), color = MutedC)
                if (Store.history.isNotEmpty()) {
                    Text(tr("الأخيرة", "Recent"), color = TextC, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Store.history.map { it.sym }.distinct().take(4).forEach { Chip(baseOf(it), false) { onSearch(it) } } }
                }
            }
            UiState.Loading -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
            is UiState.Error -> Panel { Text(st.msg, color = RedC) }
            is UiState.Done -> ReportView(st.r, vm)
        }
        Text(tr("هذا ليس نصيحة مالية. لا يوجد تحليل دقيق 100%. استخدم وقف الخسارة دائماً.", "Not financial advice. No analysis is 100% accurate. Always use a stop loss."), color = MutedC, fontSize = 11.sp)
    }
}

private fun summaryText(r: Report): String {
    val trend = when (r.regime.name) {
        "Bullish" -> tr("الاتجاه العام للسوق صاعد.", "The overall market is bullish.")
        "Bearish" -> tr("الاتجاه العام للسوق هابط.", "The overall market is bearish.")
        else -> tr("الاتجاه العام للسوق محايد.", "The overall market is neutral.")
    }
    val body = when {
        r.score >= 4 -> tr("الإشارات الفنية متوافقة وقوة الزخم جيدة. يُفضّل الدخول من مناطق الدخول المحددة بدل مطاردة السعر.", "Technical signals agree and momentum is solid. Prefer the marked entry zones over chasing price.")
        r.score == 3 -> tr("الإشارات متباينة ولا يوجد تأكيد كافٍ بعد. الأفضل الانتظار حتى يقترب السعر من منطقة دخول واضحة.", "Signals are mixed with no clear confirmation. Better to wait for price to reach a clear entry zone.")
        else -> tr("الإشارة ضعيفة والمخاطرة مرتفعة. يُفضّل تجنب العملة حالياً أو الانتظار حتى تتحسن البنية السعرية.", "The signal is weak and risk is high. Better to avoid this coin for now or wait for structure to improve.")
    }
    return "$trend $body"
}

@Composable
fun ReportView(r: Report, vm: MainViewModel) {
    val col = scoreColor(r.score)
    val strength = strengthOf(r.score, r.confidence)
    val fav = r.symbol in Store.favorites
    var ind by rememberSaveable { mutableStateOf("RSI") }
    var full by rememberSaveable { mutableStateOf(false) }

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        CoinLogo(r.symbol, 48.dp)
        Column(Modifier.weight(1f)) {
            Text(baseOf(r.symbol), color = TextC, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(coinName(r.symbol), color = MutedC, fontSize = 12.sp)
        }
        Icon(Icons.Filled.Star, contentDescription = "Favorite", tint = if (fav) Gold else MutedC, modifier = Modifier.size(28.dp).clickable { Store.toggleFav(r.symbol) })
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(fmtUsd(r.price), color = TextC, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("${fmtPct(r.change24h)} (24h)", color = if (r.change24h >= 0) GreenC else RedC, fontSize = 13.sp)
        }
        SignalBox(strength)
    }
    if (r.score <= 1) Banner(tr("تجنب هذه العملة. لا تدخل الآن.", "AVOID THIS COIN. Do not enter now."), RedC, r.warnings)
    else if (r.score == 2) Banner(tr("إعداد ضعيف: لا توجد مناطق دخول. انتظر بنية أفضل.", "Weak setup: no entry zones. Wait for a better structure."), OrangeC, r.warnings)

    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { TFS.forEach { (k, l) -> Chip(l, vm.chartTf == k, Modifier.weight(1f), 0.dp) { vm.loadChart(r.symbol, k) } } }
    Panel {
        val cs = vm.chart
        if (cs.size < 30) Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
        else {
            val n = min(70, cs.size)
            val closes = cs.map { it.c }
            val e20 = Ind.ema(closes, 20).takeLast(n); val e50 = Ind.ema(closes, 50).takeLast(n)
            val lines = listOfNotNull(r.stop?.let { it to RedC }) + r.targets.map { it.price to Gold }
            CandleChart(cs.takeLast(n), e20, e50, r.entries, lines, Modifier.fillMaxWidth().height(230.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("— EMA20", color = Gold, fontSize = 10.sp); Text("— EMA50", color = PurpleC, fontSize = 10.sp)
                if (r.entries.isNotEmpty()) { Text(tr("▮ دخول", "▮ Entry"), color = GreenC, fontSize = 10.sp); Text("- - TP", color = Gold, fontSize = 10.sp); Text(tr("- - وقف", "- - Stop"), color = RedC, fontSize = 10.sp) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("RSI", "MACD", "EMA", "Volume").forEach { Chip(it, ind == it, Modifier.weight(1f), 4.dp) { ind = it } } }
            IndicatorPanel(ind, cs, n, Modifier.fillMaxWidth().height(80.dp))
        }
    }

    SectionTitle(tr("ملخص التحليل", "Analysis Summary"))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1.35f).clip(RoundedCornerShape(16.dp)).background(col.copy(alpha = 0.10f)).border(1.dp, col.copy(alpha = 0.45f), RoundedCornerShape(16.dp)).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(col.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                Text(if (r.score >= 4) "↗" else if (r.score == 3) "→" else "↘", color = col, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Column {
                Text(tr("توصية:", "Recommendation:"), color = MutedC, fontSize = 11.sp)
                Text(verdict(r.score), color = col, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            }
        }
        Row(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(16.dp)).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Ring(r.confidence / 100f, "${r.confidence}%", col, 56.dp)
            Text(tr("درجة الثقة", "Confidence"), color = MutedC, fontSize = 11.sp)
        }
    }
    Panel { Text(summaryText(r), color = TextC, fontSize = 13.sp, lineHeight = 20.sp) }

    Panel(tr("مستويات مهمة", "Key Levels")) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(RedC))
            Text(tr("المقاومة", "Resistance"), color = TextC, fontSize = 13.sp, modifier = Modifier.weight(1f))
            if (r.resistances.isEmpty()) Text("—", color = MutedC) else r.resistances.take(2).forEach { Text(fmtUsd(it), color = RedC, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(GreenC))
            Text(tr("الدعم", "Support"), color = TextC, fontSize = 13.sp, modifier = Modifier.weight(1f))
            if (r.supports.isEmpty()) Text("—", color = MutedC) else r.supports.take(2).forEach { Text(fmtUsd(it), color = GreenC, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
        }
    }

    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Brush.horizontalGradient(listOf(Color(0xFFFFC83D), Color(0xFFF59E0B)))).clickable { full = !full }.padding(vertical = 15.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (full) tr("إخفاء التحليل الكامل", "Hide full analysis") else tr("عرض التحليل الكامل", "View full analysis"), color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        Text(if (full) "  ˄" else "  ›", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
    }

    if (full) {
        if (r.entries.isNotEmpty()) {
            Panel(tr("مناطق الدخول (تدرّج، الأفضل أولاً)", "Entry Zones (scale in, best first)")) {
                r.entries.forEachIndexed { i, z ->
                    Column {
                        Text("E${i + 1}:  ${fmtUsd(z.low)} – ${fmtUsd(z.high)}", color = GreenC, fontWeight = FontWeight.Bold)
                        Text("Confluence ${z.confluence}: ${z.why.joinToString(", ")}", color = MutedC, fontSize = 12.sp)
                    }
                }
            }
            Panel(tr("الأهداف", "Targets")) {
                r.targets.forEach {
                    Column {
                        Text("${it.label}:  ${fmtUsd(it.price)}   (${String.format(Locale.US, "%+.1f%%", it.gainPct)})", color = Gold, fontWeight = FontWeight.Bold)
                        Text(it.basis, color = MutedC, fontSize = 12.sp)
                    }
                }
            }
            Panel(tr("المخاطرة", "Risk")) {
                r.stop?.let { Text(tr("وقف الخسارة: ${fmtUsd(it)}  (الإغلاق تحته يلغي الإعداد)", "Stop loss: ${fmtUsd(it)}  (a close below invalidates the setup)"), color = RedC, fontWeight = FontWeight.Bold) }
                r.rrFirst?.let { Text(String.format(Locale.US, "R/R  TP1: %.2f   |   final: %.2f", it, r.rrFinal ?: it), color = TextC, fontSize = 13.sp) }
            }
        }
        Panel(tr("لماذا هذا التقييم", "Why this score")) { r.reasons.forEach { Text("• $it", color = TextC, fontSize = 13.sp) } }
        if (r.warnings.isNotEmpty() && r.score >= 3) Panel(tr("تحذيرات", "Warnings")) { r.warnings.forEach { Text("• $it", color = OrangeC, fontSize = 13.sp) } }
        Panel(tr("حالة السوق: ", "Market Regime: ") + regimeText(r.regime.name)) { r.regime.notes.forEach { Text("• $it", color = MutedC, fontSize = 12.sp) } }
        Panel(tr("التفصيل حسب المدارس", "Breakdown by school")) {
            r.tfs.forEach { t ->
                Text(String.format(Locale.US, "%s  (weight %.0f%%)  total %+.0f", t.tf.uppercase(), t.weight * 100, t.total), color = signColor(t.total), fontWeight = FontWeight.Bold)
                t.schools.forEach { s ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(s.name, color = TextC, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(String.format(Locale.US, "%+.0f", s.score), color = signColor(s.score), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(s.note, color = MutedC, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun Banner(title: String, color: Color, why: List<String>) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.16f)).border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(14.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = color, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        why.forEach { Text("• $it", color = TextC, fontSize = 13.sp) }
    }
}
