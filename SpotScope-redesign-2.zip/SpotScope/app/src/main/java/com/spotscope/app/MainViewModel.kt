package com.spotscope.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

sealed interface UiState {
    object Idle : UiState
    object Loading : UiState
    data class Error(val msg: String) : UiState
    data class Done(val r: Report) : UiState
}

class MainViewModel : ViewModel() {
    var state by mutableStateOf<UiState>(UiState.Idle)
        private set
    var chart by mutableStateOf<List<Candle>>(emptyList())
        private set
    var chartTf by mutableStateOf(Store.defaultTf)
        private set

    fun analyze(q: String) {
        if (state is UiState.Loading) return
        viewModelScope.launch {
            state = UiState.Loading
            chart = emptyList()
            state = try {
                val r = Analyzer.analyze(q)
                Store.addHistory(HistoryItem(r.symbol, r.score, r.price, System.currentTimeMillis(), strengthOf(r.score, r.confidence)))
                UiState.Done(r)
            } catch (e: SymbolNotFound) { UiState.Error(tr("لم يتم العثور على العملة في Binance Spot (زوج USDT). تحقق من الاسم.", "Coin not found on Binance Spot (USDT pair). Check the name.")) }
            catch (e: Exception) { UiState.Error(e.message ?: tr("خطأ في الشبكة. حاول مرة أخرى.", "Network error. Try again.")) }
            (state as? UiState.Done)?.let { loadChart(it.r.symbol, chartTf) }
        }
    }

    fun loadChart(sym: String, tf: String) {
        chartTf = tf
        viewModelScope.launch { chart = runCatching { Binance.klines(sym, tf, 200) }.getOrDefault(emptyList()) }
    }
}
