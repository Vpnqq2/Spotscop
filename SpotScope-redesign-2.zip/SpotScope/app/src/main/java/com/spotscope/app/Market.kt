package com.spotscope.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Overview(val totalCap: Double?, val capChange: Double?, val btcDom: Double?)
data class Tick(val sym: String, val last: Double, val change: Double, val quoteVol: Double)
data class ScanItem(val sym: String, val price: Double, val change: Double, val score: Int, val confidence: Int, val label: String, val strength: Int)

object MarketData {
    private var tickCache: Pair<Long, List<Tick>>? = null
    private var ovCache: Pair<Long, Overview>? = null
    private val sparkCache = HashMap<String, Pair<Long, List<Double>>>()
    private val skip = setOf("USDC", "FDUSD", "TUSD", "BUSD", "USDP", "DAI", "EUR", "USD1", "XUSD", "AEUR", "USDE", "PAXG", "EURI")

    suspend fun tickers(): List<Tick> {
        tickCache?.let { if (System.currentTimeMillis() - it.first < 30_000) return it.second }
        val list = Binance.allTickers().filter { it.first.endsWith("USDT") }.map { Tick(it.first, it.second.last, it.second.changePct, it.second.quoteVolume) }
            .filter { t ->
                val b = t.sym.removeSuffix("USDT")
                b !in skip && !b.endsWith("UP") && !b.endsWith("DOWN") && !b.endsWith("BULL") && !b.endsWith("BEAR") && t.quoteVol > 0
            }
        tickCache = System.currentTimeMillis() to list
        return list
    }

    suspend fun top(n: Int): List<Tick> = tickers().sortedByDescending { it.quoteVol }.take(n)

    suspend fun spark(sym: String): List<Double> {
        sparkCache[sym]?.let { if (System.currentTimeMillis() - it.first < 300_000) return it.second }
        val v = Binance.klines(sym, "1h", 24).map { it.c }
        sparkCache[sym] = System.currentTimeMillis() to v
        return v
    }

    suspend fun overview(): Overview {
        ovCache?.let { if (System.currentTimeMillis() - it.first < 300_000) return it.second }
        val o = withContext(Dispatchers.IO) {
            runCatching {
                val c = URL("https://api.coingecko.com/api/v3/global").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 10000
                val d = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONObject("data")
                Overview(d.getJSONObject("total_market_cap").getDouble("usd"), d.optDouble("market_cap_change_percentage_24h_usd"), d.getJSONObject("market_cap_percentage").getDouble("btc"))
            }.getOrDefault(Overview(null, null, null))
        }
        if (o.totalCap != null) ovCache = System.currentTimeMillis() to o
        return o
    }
}

/** Background quick-scan of the most liquid coins (+ favorites), scored 1-5. */
object Scanner {
    val items = mutableStateMapOf<String, ScanItem>()
    var running by mutableStateOf(false); private set
    var done by mutableIntStateOf(0); private set
    var total by mutableIntStateOf(0); private set
    private var last = 0L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    fun ensure(force: Boolean = false) {
        if (running) return
        if (!force && items.isNotEmpty() && System.currentTimeMillis() - last < 600_000) return
        running = true
        scope.launch {
            try {
                val syms = (MarketData.top(16).map { it.sym } + Store.favorites).distinct()
                total = syms.size; done = 0
                runCatching { Analyzer.regime() }
                val sem = Semaphore(4)
                syms.map { s ->
                    async {
                        sem.withPermit {
                            runCatching { Analyzer.analyze(s, false) }.getOrNull()?.let {
                                items[it.symbol] = ScanItem(it.symbol, it.price, it.change24h, it.score, it.confidence, it.label, strengthOf(it.score, it.confidence))
                            }
                            done += 1
                        }
                    }
                }.awaitAll()
                last = System.currentTimeMillis()
            } catch (e: Exception) { /* keep partial results */ } finally { running = false }
        }
    }
}
