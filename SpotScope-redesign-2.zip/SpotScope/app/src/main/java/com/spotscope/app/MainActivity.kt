package com.spotscope.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = BgC, surface = CardC, onSurface = TextC, onBackground = TextC)) {
                CompositionLocalProvider(LocalTextStyle provides TextStyle(textAlign = TextAlign.Left)) { App() }
            }
        }
    }
}

@Composable
fun App(vm: MainViewModel = viewModel()) {
    var splash by rememberSaveable { mutableStateOf(true) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var sub by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(Unit) { delay(1800); splash = false }
    if (splash) { SplashScreen(); return }

    fun open(sym: String) { vm.analyze(sym); tab = 2; sub = "" }
    BackHandler(enabled = sub != "" || tab != 0) { if (sub != "") sub = "" else tab = 0 }

    Column(Modifier.fillMaxSize().background(BgC)) {
        Box(Modifier.weight(1f)) {
            when (sub) {
                "discover" -> DiscoverScreen({ sub = "" }) { open(it) }
                "history" -> HistoryScreen({ sub = "" }) { open(it) }
                else -> when (tab) {
                    0 -> HomeScreen({ open(it) }) { sub = "discover" }
                    1 -> MarketsScreen({ open(it) }) { sub = "discover" }
                    2 -> AnalyzeScreen(vm, { tab = 0 }) { open(it) }
                    3 -> FavoritesScreen { open(it) }
                    else -> MoreScreen { sub = it }
                }
            }
        }
        BottomBar(if (sub == "discover") 1 else if (sub == "history") 4 else tab) { tab = it; sub = "" }
    }
}

@Composable
fun BottomBar(sel: Int, onSel: (Int) -> Unit) {
    val labels = listOf(tr("الرئيسية", "Home"), tr("الأسواق", "Markets"), tr("تحليل العملات", "Analyze"), tr("المفضلة", "Favorites"), tr("المزيد", "More"))
    Column(Modifier.fillMaxWidth().background(CardC)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(BorderC))
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            labels.forEachIndexed { i, label ->
                val c = if (sel == i) Gold else MutedC
                Column(Modifier.weight(1f).clickable { onSel(i) }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    when (i) {
                        0 -> NavIcon("home", c)
                        1 -> NavIcon("markets", c)
                        2 -> NavIcon("analyze", c)
                        3 -> Icon(Icons.Filled.Star, contentDescription = label, tint = c, modifier = Modifier.size(22.dp))
                        else -> NavIcon("more", c)
                    }
                    Text(label, color = c, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center)
                }
            }
        }
    }
}
