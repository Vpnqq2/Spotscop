package com.spotscope.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.*

val BgC = Color(0xFF070B14); val CardC = Color(0xFF0D1422); val CardHi = Color(0xFF111B2E); val BorderC = Color(0xFF1B2740)
val Gold = Color(0xFFFFB400); val GreenC = Color(0xFF1ED48B); val RedC = Color(0xFFFF4D5E); val OrangeC = Color(0xFFFF8A3D)
val TextC = Color(0xFFF2F5FA); val MutedC = Color(0xFF8795AD); val BlueC = Color(0xFF5B8DEF); val PurpleC = Color(0xFFB57CFF)

/** English is the default UI language; switch in Settings. */
fun tr(ar: String, en: String) = if (Store.lang == "ar") ar else en

/** Signal strength 0-100 derived from the 1-5 score band and the confidence inside that band. */
fun strengthOf(score: Int, conf: Int): Int {
    val (lo, hi) = when (score) { 5 -> 80 to 96; 4 -> 66 to 79; 3 -> 50 to 65; 2 -> 36 to 49; else -> 15 to 35 }
    return lo + ((hi - lo) * conf.coerceIn(0, 100) / 100f).roundToInt()
}
fun ringColor(s: Int) = if (s >= 66) GreenC else if (s >= 50) Gold else if (s >= 36) OrangeC else RedC
fun scoreColor(s: Int) = when (s) { 5, 4 -> GreenC; 3 -> Gold; 2 -> OrangeC; else -> RedC }
fun signColor(x: Double) = if (x > 10) GreenC else if (x < -10) RedC else MutedC
fun regimeColor(n: String) = when (n) { "Bullish" -> GreenC; "Bearish" -> RedC; else -> Gold }
fun regimeText(n: String) = when (n) { "Bullish" -> tr("صاعد", "Bullish"); "Bearish" -> tr("هابط", "Bearish"); else -> tr("محايد", "Neutral") }
fun verdict(score: Int) = if (score >= 4) tr("محتمل شراء", "Potential buy") else if (score == 3) tr("انتظار", "Wait") else tr("تجنب", "Avoid")

fun fmtPrice(p: Double): String {
    if (p >= 1000) return String.format(Locale.US, "%,.2f", p)
    val d = when { p >= 1 -> 4; p >= 0.01 -> 5; else -> 8 }
    var s = String.format(Locale.US, "%.${d}f", p)
    val dot = s.indexOf('.')
    while (s.length - dot - 1 > 2 && s.endsWith("0")) s = s.dropLast(1)
    return s
}
fun fmtUsd(p: Double) = "\$" + fmtPrice(p)
fun fmtPct(x: Double) = String.format(Locale.US, "%+.2f%%", x)
fun fmtBig(x: Double) = when {
    x >= 1e12 -> String.format(Locale.US, "\$%.2fT", x / 1e12)
    x >= 1e9 -> String.format(Locale.US, "\$%.2fB", x / 1e9)
    else -> String.format(Locale.US, "\$%.1fM", x / 1e6)
}
fun baseOf(sym: String) = sym.removeSuffix("USDT")

private val names = mapOf(
    "BTC" to "Bitcoin", "ETH" to "Ethereum", "BNB" to "BNB", "SOL" to "Solana", "XRP" to "XRP", "ADA" to "Cardano", "DOGE" to "Dogecoin",
    "AVAX" to "Avalanche", "DOT" to "Polkadot", "LINK" to "Chainlink", "POL" to "Polygon", "MATIC" to "Polygon", "LTC" to "Litecoin",
    "TRX" to "TRON", "SHIB" to "Shiba Inu", "TON" to "Toncoin", "UNI" to "Uniswap", "ATOM" to "Cosmos", "NEAR" to "NEAR Protocol",
    "ARB" to "Arbitrum", "OP" to "Optimism", "APT" to "Aptos", "SUI" to "Sui", "PEPE" to "Pepe", "FIL" to "Filecoin", "ETC" to "Ethereum Classic",
    "BCH" to "Bitcoin Cash", "XLM" to "Stellar", "INJ" to "Injective", "AAVE" to "Aave", "ICP" to "Internet Computer", "HBAR" to "Hedera"
)
fun coinName(sym: String) = names[baseOf(sym)] ?: "Crypto · USDT"

// ------------------------------------------------------------------ animation helpers
/** Fade + slide-up entrance, optionally staggered by index. */
fun Modifier.appear(index: Int = 0): Modifier = composed {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(index.coerceAtMost(8) * 70L); a.animateTo(1f, tween(500, easing = FastOutSlowInEasing)) }
    graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 40f }
}

@Composable
fun PulseDot(color: Color = GreenC, dia: Dp = 8.dp) {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(1f, 2.4f, infiniteRepeatable(tween(1200), RepeatMode.Restart), label = "s")
    Box(Modifier.size(dia * 2.4f), contentAlignment = Alignment.Center) {
        Box(Modifier.size(dia).graphicsLayer { scaleX = s; scaleY = s; alpha = ((2.4f - s) / 1.4f).coerceIn(0f, 1f) * 0.5f }.clip(CircleShape).background(color))
        Box(Modifier.size(dia).clip(CircleShape).background(color))
    }
}

// ------------------------------------------------------------------ building blocks
@Composable
fun Panel(title: String? = null, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.appear().fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (title != null) Text(title, color = TextC, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        content()
    }
}

@Composable
fun Chip(text: String, selected: Boolean, modifier: Modifier = Modifier, hPad: Dp = 14.dp, onClick: () -> Unit) {
    Text(
        text, color = if (selected) Color.Black else MutedC, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 1,
        modifier = modifier.clip(RoundedCornerShape(20.dp)).background(if (selected) Gold else CardC)
            .border(1.dp, if (selected) Gold else BorderC, RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(horizontal = hPad, vertical = 7.dp)
    )
}

@Composable
fun MiniBtn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Text(
        text, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 1,
        modifier = modifier.clip(RoundedCornerShape(8.dp)).background(Gold.copy(alpha = 0.08f)).border(1.dp, Gold.copy(alpha = 0.65f), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 5.dp)
    )
}

@Composable
fun Avatar(sym: String, dia: Dp = 36.dp) {
    val b = baseOf(sym); val hue = ((b.hashCode() and 0x7fffffff) % 360).toFloat()
    Box(Modifier.size(dia).clip(CircleShape).background(Color.hsv(hue, 0.55f, 0.72f)), contentAlignment = Alignment.Center) {
        Text(b.take(2), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (dia.value * 0.36f).sp)
    }
}

/** Coin logo from the web (CoinGecko / CC0 icon set); falls back to a colored letter avatar. */
@Composable
fun CoinLogo(sym: String, dia: Dp = 36.dp) {
    val b = baseOf(sym).lowercase(Locale.US)
    val cg = CoinIcons.urls[b]
    // Licensed sources only: CoinGecko public API images, then the CC0 "cryptocurrency-icons" set.
    val urls = remember(b, cg) { listOfNotNull(cg, "https://cdn.jsdelivr.net/gh/spothq/cryptocurrency-icons@master/128/color/$b.png") }
    var idx by remember(b, cg) { mutableIntStateOf(0) }
    if (idx >= urls.size) Avatar(sym, dia)
    else Box(Modifier.size(dia).clip(CircleShape).background(CardHi)) {
        AsyncImage(model = urls[idx], contentDescription = b, modifier = Modifier.fillMaxSize(), onError = { idx += 1 })
    }
}

@Composable
fun Ring(frac: Float, text: String, color: Color, dia: Dp, sub: String? = null) {
    val prog = remember { Animatable(0f) }
    LaunchedEffect(frac) { prog.animateTo(frac.coerceIn(0f, 1f), tween(900, easing = FastOutSlowInEasing)) }
    Box(Modifier.size(dia), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = this.size.minDimension * 0.09f
            val inset = sw / 2
            val arcSize = Size(this.size.width - sw, this.size.height - sw)
            drawArc(color.copy(alpha = 0.18f), -90f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(sw))
            drawArc(color, -90f, 360f * prog.value, false, Offset(inset, inset), arcSize, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text, color = color, fontWeight = FontWeight.ExtraBold, fontSize = (dia.value * 0.30f).sp, textAlign = TextAlign.Center)
            if (sub != null) Text(sub, color = MutedC, fontSize = (dia.value * 0.13f).sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun ScoreRing(strength: Int?, dia: Dp = 34.dp) =
    Ring((strength ?: 0) / 100f, strength?.toString() ?: "–", if (strength == null) MutedC else ringColor(strength), dia)

@Composable
fun Sparkline(v: List<Double>, color: Color, modifier: Modifier = Modifier) {
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(v.size > 1) { if (v.size > 1) { reveal.snapTo(0f); reveal.animateTo(1f, tween(1000, easing = FastOutSlowInEasing)) } }
    Canvas(modifier) {
        if (v.size < 2) return@Canvas
        val mn = v.min(); val mx = v.max(); val rg = max(mx - mn, 1e-12)
        val w = this.size.width; val h = this.size.height
        val line = Path(); val fill = Path()
        v.forEachIndexed { i, x ->
            val px = w * i / (v.size - 1)
            val py = h * 0.08f + h * 0.84f * (1 - (x - mn) / rg).toFloat()
            if (i == 0) { line.moveTo(px, py); fill.moveTo(px, py) } else { line.lineTo(px, py); fill.lineTo(px, py) }
        }
        fill.lineTo(w, h); fill.lineTo(0f, h); fill.close()
        clipRect(0f, 0f, w * reveal.value, h) {
            drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.22f), Color.Transparent)))
            drawPath(line, color, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, color = TextC, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = modifier)
}

@Composable
fun LogoMark(dia: Dp) {
    Canvas(Modifier.size(dia)) {
        val w = this.size.width; val h = this.size.height
        val bw = w * 0.26f; val gap = w * 0.11f
        val brush = Brush.verticalGradient(listOf(Color(0xFFFFD34D), Color(0xFFE68A00)))
        listOf(0.42f, 0.70f, 1f).forEachIndexed { i, f ->
            drawRoundRect(brush, Offset(i * (bw + gap), h * (1 - f)), Size(bw, h * f), CornerRadius(bw * 0.28f))
        }
    }
}

@Composable
fun NavIcon(kind: String, tint: Color, dia: Dp = 22.dp) {
    Canvas(Modifier.size(dia)) {
        val w = this.size.width; val h = this.size.height; val sw = w * 0.09f
        val st = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            "home" -> {
                val p = Path()
                p.moveTo(0.12f * w, 0.48f * h); p.lineTo(0.5f * w, 0.14f * h); p.lineTo(0.88f * w, 0.48f * h)
                p.moveTo(0.22f * w, 0.42f * h); p.lineTo(0.22f * w, 0.86f * h); p.lineTo(0.78f * w, 0.86f * h); p.lineTo(0.78f * w, 0.42f * h)
                drawPath(p, tint, style = st)
            }
            "markets" -> listOf(0.22f to 0.55f, 0.5f to 0.25f, 0.78f to 0.4f).forEach { (x, top) ->
                drawLine(tint, Offset(x * w, 0.86f * h), Offset(x * w, top * h + 0.12f * h), strokeWidth = w * 0.15f, cap = StrokeCap.Round)
            }
            "analyze" -> {
                val p = Path()
                p.moveTo(0.1f * w, 0.72f * h); p.lineTo(0.35f * w, 0.46f * h); p.lineTo(0.55f * w, 0.62f * h); p.lineTo(0.88f * w, 0.2f * h)
                drawPath(p, tint, style = st)
                drawLine(tint, Offset(0.1f * w, 0.9f * h), Offset(0.9f * w, 0.9f * h), strokeWidth = sw, cap = StrokeCap.Round)
            }
            "more" -> listOf(0.2f, 0.5f, 0.8f).forEach { drawCircle(tint, w * 0.075f, Offset(it * w, 0.5f * h)) }
            "history" -> {
                drawCircle(tint, w * 0.38f, Offset(w / 2, h / 2), style = st)
                drawLine(tint, Offset(w / 2, h / 2), Offset(w / 2, 0.26f * h), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, Offset(w / 2, h / 2), Offset(0.68f * w, 0.58f * h), strokeWidth = sw, cap = StrokeCap.Round)
            }
            "globe" -> {
                drawCircle(tint, w * 0.38f, Offset(w / 2, h / 2), style = st)
                drawOval(tint, Offset(0.31f * w, 0.12f * h), Size(0.38f * w, 0.76f * h), style = st)
                drawLine(tint, Offset(0.12f * w, h / 2), Offset(0.88f * w, h / 2), strokeWidth = sw)
            }
        }
    }
}

@Composable
fun CircleGlyph(ch: String, tint: Color, dia: Dp = 22.dp) {
    Box(Modifier.size(dia).border(1.5.dp, tint, CircleShape), contentAlignment = Alignment.Center) {
        Text(ch, color = tint, fontSize = (dia.value * 0.55f).sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
fun SignalBox(strength: Int) {
    val c = ringColor(strength)
    Column(
        Modifier.clip(RoundedCornerShape(14.dp)).background(c.copy(alpha = 0.10f)).border(1.dp, c.copy(alpha = 0.6f), RoundedCornerShape(14.dp)).padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(tr("قوة الإشارة", "Signal strength"), color = TextC, fontSize = 11.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(strength.toString(), color = c, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("/100", color = MutedC, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
        }
    }
}

// ------------------------------------------------------------------ charts
@Composable
fun CandleChart(cs: List<Candle>, e20: List<Double>, e50: List<Double>, zones: List<Zone>, lines: List<Pair<Double, Color>>, modifier: Modifier) {
    val tm = rememberTextMeasurer()
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(cs.firstOrNull()?.t) { reveal.snapTo(0f); reveal.animateTo(1f, tween(800, easing = FastOutSlowInEasing)) }
    Canvas(modifier) {
        val n = cs.size
        if (n < 2) return@Canvas
        clipRect(0f, 0f, this.size.width * reveal.value, this.size.height) {
        val w = this.size.width - 52.dp.toPx(); val h = this.size.height
        var mx = cs.maxOf { it.h }; var mn = cs.minOf { it.l }
        val pad = (mx - mn) * 0.05; mx += pad; mn -= pad
        fun y(p: Double) = (h * (1 - (p - mn) / (mx - mn))).toFloat()
        val lbl = TextStyle(color = MutedC, fontSize = 9.sp)
        for (i in 0..4) {
            val p = mn + (mx - mn) * i / 4; val yy = y(p)
            drawLine(BorderC, Offset(0f, yy), Offset(w, yy), 1f)
            drawText(tm, fmtPrice(p), Offset(w + 4.dp.toPx(), yy - 6.dp.toPx()), lbl)
        }
        zones.forEach { z ->
            val t = max(y(z.high), 0f); val b = min(y(z.low), h)
            if (b > t) drawRect(GreenC.copy(alpha = 0.15f), Offset(0f, t), Size(w, b - t))
        }
        val cw = w / n
        val vmax = max(cs.maxOf { it.v }, 1e-12)
        cs.forEachIndexed { i, c ->
            val bh = (c.v / vmax * h * 0.16).toFloat()
            drawRect((if (c.c >= c.o) GreenC else RedC).copy(alpha = 0.30f), Offset(cw * i + cw * 0.15f, h - bh), Size(cw * 0.7f, max(bh, 1f)))
        }
        lines.forEach { (p, c) ->
            if (p in mn..mx) drawLine(c, Offset(0f, y(p)), Offset(w, y(p)), 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
        }
        cs.forEachIndexed { i, c ->
            val x = cw * i + cw / 2; val col = if (c.c >= c.o) GreenC else RedC
            drawLine(col, Offset(x, y(c.h)), Offset(x, y(c.l)), 1f)
            val top = y(max(c.o, c.c)); val bot = y(min(c.o, c.c))
            drawRect(col, Offset(x - cw * 0.35f, top), Size(cw * 0.7f, max(bot - top, 1f)))
        }
        fun line(v: List<Double>, col: Color) {
            val p = Path()
            v.forEachIndexed { i, x -> val px = cw * i + cw / 2; if (i == 0) p.moveTo(px, y(x)) else p.lineTo(px, y(x)) }
            drawPath(p, col, style = Stroke(1.5f))
        }
        line(e20, Gold); line(e50, PurpleC)
        val last = cs.last().c
        drawLine(MutedC.copy(alpha = 0.6f), Offset(0f, y(last)), Offset(w, y(last)), 1f)
        drawText(tm, fmtPrice(last), Offset(w + 4.dp.toPx(), y(last) - 6.dp.toPx()),
            TextStyle(color = Color.Black, background = if (last >= cs.last().o) GreenC else RedC, fontSize = 9.sp))
        }
    }
}

@Composable
fun IndicatorPanel(kind: String, all: List<Candle>, n: Int, modifier: Modifier) {
    val closes = remember(all) { all.map { it.c } }
    val rsi = remember(all) { Ind.rsi(closes).takeLast(n) }
    val hist = remember(all) { Ind.macdHist(closes).takeLast(n) }
    val em20 = remember(all) { Ind.ema(closes, 20).takeLast(n) }
    val em50 = remember(all) { Ind.ema(closes, 50).takeLast(n) }
    val vis = all.takeLast(n)
    val tm = rememberTextMeasurer()
    Canvas(modifier.clip(RoundedCornerShape(10.dp)).background(CardHi.copy(alpha = 0.5f))) {
        if (vis.size < 2) return@Canvas
        val w = this.size.width - 52.dp.toPx(); val h = this.size.height; val cw = w / n
        val lbl = TextStyle(color = MutedC, fontSize = 9.sp)
        when (kind) {
            "RSI" -> {
                fun y(v: Double) = (h * (1 - v / 100)).toFloat()
                listOf(30.0, 70.0).forEach { drawLine(BorderC, Offset(0f, y(it)), Offset(w, y(it)), 1f); drawText(tm, it.toInt().toString(), Offset(w + 4.dp.toPx(), y(it) - 6.dp.toPx()), lbl) }
                val p = Path()
                rsi.forEachIndexed { i, v -> val px = cw * i + cw / 2; if (i == 0) p.moveTo(px, y(v)) else p.lineTo(px, y(v)) }
                drawPath(p, PurpleC, style = Stroke(2f))
                drawText(tm, String.format(Locale.US, "%.0f", rsi.last()), Offset(w + 4.dp.toPx(), y(rsi.last()) - 6.dp.toPx()), TextStyle(color = PurpleC, fontSize = 10.sp))
            }
            "MACD" -> {
                val m = max(hist.maxOf { abs(it) }, 1e-12)
                drawLine(BorderC, Offset(0f, h / 2), Offset(w, h / 2), 1f)
                hist.forEachIndexed { i, v ->
                    val bh = (abs(v) / m * (h / 2)).toFloat()
                    drawRect(if (v >= 0) GreenC else RedC, Offset(cw * i + cw * 0.15f, if (v >= 0) h / 2 - bh else h / 2), Size(cw * 0.7f, max(bh, 1f)))
                }
            }
            "EMA" -> {
                val both = em20 + em50
                val mx = both.max(); val mn = both.min(); val rg = max(mx - mn, 1e-12)
                fun y(v: Double) = (h * 0.1f + h * 0.8f * (1 - (v - mn) / rg)).toFloat()
                fun line(l: List<Double>, col: Color) {
                    val p = Path()
                    l.forEachIndexed { i, v -> val px = cw * i + cw / 2; if (i == 0) p.moveTo(px, y(v)) else p.lineTo(px, y(v)) }
                    drawPath(p, col, style = Stroke(2f))
                }
                line(em20, Gold); line(em50, PurpleC)
            }
            else -> {
                val m = max(vis.maxOf { it.v }, 1e-12)
                vis.forEachIndexed { i, c ->
                    val bh = (c.v / m * h).toFloat()
                    drawRect((if (c.c >= c.o) GreenC else RedC).copy(alpha = 0.8f), Offset(cw * i + cw * 0.15f, h - bh), Size(cw * 0.7f, max(bh, 1f)))
                }
            }
        }
    }
}
