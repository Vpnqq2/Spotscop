package com.spotscope.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.Locale

private val BgC = Color(0xFF0B0F14); private val CardC = Color(0xFF141A22)
private val Gold = Color(0xFFF0B90B); private val GreenC = Color(0xFF2EBD85)
private val RedC = Color(0xFFF6465D); private val OrangeC = Color(0xFFFF8A3D)
private val TextC = Color(0xFFEAECEF); private val MutedC = Color(0xFF848E9C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = BgC, surface = CardC, onSurface = TextC, onBackground = TextC)) { App() }
        }
    }
}

private fun price(p: Double) = String.format(Locale.US, when { p >= 1000 -> "%.2f"; p >= 1 -> "%.4f"; p >= 0.01 -> "%.5f"; else -> "%.8f" }, p)
private fun pct(x: Double) = String.format(Locale.US, "%+.1f%%", x)
private fun scoreColor(s: Int) = when (s) { 5, 4 -> GreenC; 3 -> Gold; 2 -> OrangeC; else -> RedC }
private fun sc(x: Double) = if (x > 10) GreenC else if (x < -10) RedC else MutedC

@Composable
fun App(vm: MainViewModel = viewModel()) {
    var q by rememberSaveable { mutableStateOf("") }
    val st = vm.state
    Surface(Modifier.fillMaxSize(), color = BgC) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("SpotScope", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("Binance Spot analyzer: multi-school, multi-timeframe", color = MutedC, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, modifier = Modifier.weight(1f), singleLine = true,
                    placeholder = { Text("BTC, ETH, SOL...", color = MutedC) },
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.analyze(q) })
                )
                Button(onClick = { vm.analyze(q) }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)) { Text("Analyze", fontWeight = FontWeight.Bold) }
            }
            when (st) {
                UiState.Idle -> Text("Type a coin name to get its score, entry zones, targets and stop loss.", color = MutedC)
                UiState.Loading -> Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
                is UiState.Error -> Panel { Text(st.msg, color = RedC) }
                is UiState.Done -> ReportView(st.r)
            }
            Text("Not financial advice. No analysis is 100% accurate. Always use a stop loss and never risk more than you can afford to lose.", color = MutedC, fontSize = 11.sp)
        }
    }
}

@Composable
fun Panel(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardC).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (title != null) Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        content()
    }
}

@Composable
fun ReportView(r: Report) {
    val col = scoreColor(r.score)
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(78.dp).clip(CircleShape).background(col), contentAlignment = Alignment.Center) {
                Text("${r.score}/5", color = Color.Black, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column {
                Text(r.symbol, color = TextC, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("${price(r.price)}  (${pct(r.change24h)} 24h)", color = if (r.change24h >= 0) GreenC else RedC, fontSize = 13.sp)
                Text("★".repeat(r.score) + "☆".repeat(5 - r.score), color = col, fontSize = 18.sp)
                Text("Confidence ${r.confidence}%", color = MutedC, fontSize = 12.sp)
            }
        }
        Text(r.label, color = col, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
    if (r.score <= 1) Banner("AVOID THIS COIN. Do not enter now.", RedC, r.warnings)
    else if (r.score == 2) Banner("Weak setup: no entry zones given. Wait for a better structure.", OrangeC, r.warnings)

    Panel("Market Regime (BTC first): ${r.regime.name}") {
        r.regime.notes.forEach { Text("• $it", color = TextC, fontSize = 13.sp) }
    }

    if (r.entries.isNotEmpty()) {
        Panel("Entry Zones (scale in, best first)") {
            r.entries.forEachIndexed { i, z ->
                Column {
                    Text("E${i + 1}:  ${price(z.low)} – ${price(z.high)}", color = GreenC, fontWeight = FontWeight.Bold)
                    Text("Confluence ${z.confluence}: ${z.why.joinToString(", ")}", color = MutedC, fontSize = 12.sp)
                }
            }
        }
        Panel("Targets") {
            r.targets.forEach {
                Column {
                    Text("${it.label}:  ${price(it.price)}   (${pct(it.gainPct)})", color = Gold, fontWeight = FontWeight.Bold)
                    Text(it.basis, color = MutedC, fontSize = 12.sp)
                }
            }
        }
        Panel("Risk") {
            r.stop?.let { Text("Stop loss: ${price(it)}  (close below invalidates the setup)", color = RedC, fontWeight = FontWeight.Bold) }
            r.rrFirst?.let { Text(String.format(Locale.US, "R/R to TP1: %.2f   |   to final target: %.2f", it, r.rrFinal ?: it), color = TextC, fontSize = 13.sp) }
        }
    }

    Panel("Why this score") { r.reasons.forEach { Text("• $it", color = TextC, fontSize = 13.sp) } }
    if (r.warnings.isNotEmpty() && r.score >= 3) Panel("Warnings") { r.warnings.forEach { Text("• $it", color = OrangeC, fontSize = 13.sp) } }

    var open by rememberSaveable { mutableStateOf(false) }
    Panel("Breakdown by school") {
        TextButton(onClick = { open = !open }) { Text(if (open) "Hide details" else "Show details", color = Gold) }
        if (open) r.tfs.forEach { t ->
            Text(String.format(Locale.US, "%s  (weight %.0f%%)  total %+.0f", t.tf.uppercase(), t.weight * 100, t.total), color = sc(t.total), fontWeight = FontWeight.Bold)
            t.schools.forEach { s ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.name, color = TextC, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(String.format(Locale.US, "%+.0f", s.score), color = sc(s.score), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Text(s.note, color = MutedC, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun Banner(title: String, color: Color, why: List<String>) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.18f)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = color, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        why.forEach { Text("• $it", color = TextC, fontSize = 13.sp) }
    }
}
