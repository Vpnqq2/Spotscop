package com.spotscope.app

import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import java.util.Locale
import kotlin.math.*

private class Lvl(val lo: Double, val hi: Double, val tag: String)

object Analyzer {
    private fun f(fmt: String, vararg a: Any) = String.format(Locale.US, fmt, *a)

    private fun tf(name: String, w: Double, cs: List<Candle>, ob: SchoolResult?): TfResult {
        val l = mutableListOf(Schools.trend(cs), Schools.momentum(cs), Schools.structure(cs), Schools.fib(cs), Schools.volume(cs),
            Schools.ichimoku(cs), Schools.smc(cs), Schools.patterns(cs), Schools.wyckoff(cs))
        if (ob != null) l.add(ob)
        return TfResult(name, w, l, l.sumOf { it.score * it.weight } / l.sumOf { it.weight })
    }

    private fun bias(cs: List<Candle>): Double {
        val l = listOf(Schools.trend(cs), Schools.structure(cs), Schools.momentum(cs), Schools.ichimoku(cs))
        return l.sumOf { it.score * it.weight } / l.sumOf { it.weight }
    }

    suspend fun analyze(input: String): Report = coroutineScope {
        val sym = Binance.normalize(input)
        val tk = Binance.ticker(sym)
        val price = tk.last
        val isBtc = sym == "BTCUSDT"
        val a1 = async { Binance.klines(sym, "1h", 300) }
        val a4 = async { Binance.klines(sym, "4h", 300) }
        val ad = async { Binance.klines(sym, "1d", 500) }
        val b4 = if (isBtc) a4 else async { Binance.klines("BTCUSDT", "4h", 300) }
        val bd = if (isBtc) ad else async { Binance.klines("BTCUSDT", "1d", 500) }
        val eb = async { runCatching { Binance.klines("ETHBTC", "1d", 120) }.getOrNull() }
        val ob = async { runCatching { Binance.orderBookImbalance(sym, price) }.getOrNull() }
        val c1 = a1.await(); val c4 = a4.await(); val cd = ad.await()
        if (cd.size < 80 || c4.size < 80 || c1.size < 80) throw IllegalStateException("Not enough price history for $sym yet")
        val btc4 = b4.await(); val btcd = bd.await()

        // ---------- 1) Market regime (BTC first) ----------
        val bias4 = bias(btc4); val biasD = bias(btcd)
        var rs = 0.6 * biasD + 0.4 * bias4
        val rn = mutableListOf(f("BTC bias: 1D %+.0f, 4H %+.0f", biasD, bias4))
        val ec = eb.await()
        if (ec != null && ec.size > 60) {
            if (ec.last().c > Ind.ema(ec.map { it.c }, 50).last()) { rs += 5; rn.add("ETH/BTC above EMA50: money rotating into alts") }
            else { rs -= 5; rn.add("ETH/BTC below EMA50: BTC dominance rising, alts under pressure") }
        }
        val b24 = (btc4.takeLast(6).last().c / btc4.takeLast(6).first().o - 1) * 100
        if (b24 < -5) { rs -= 15; rn.add(f("BTC fell %.1f%% in 24h: risk-off", b24)) }
        val regime = Regime(when { rs >= 25 -> "Bullish"; rs <= -25 -> "Bearish"; else -> "Neutral" }, rs, rn)

        // ---------- 2) Coin analysis (all schools x 3 timeframes) ----------
        val obRes = ob.await()?.let { SchoolResult("Order Book", clamp(it * 120), f("Bid/ask imbalance %+.0f%% within 3%% of price", it * 100), 0.5) }
        val tfs = listOf(tf("1h", 0.20, c1, obRes), tf("4h", 0.35, c4, null), tf("1d", 0.45, cd, null))
        val overall = tfs.sumOf { it.total * it.weight }
        val adj = if (isBtc) 0.0 else clamp(regime.score * 0.3, -20.0, 12.0)
        val finalS = overall + adj
        val d1 = tfs[2].total; val h4 = tfs[1].total

        val dir = if (finalS >= 0) 1.0 else -1.0
        val voting = tfs.flatMap { it.schools }.filter { abs(it.score) > 10 }
        val agree = if (voting.isEmpty()) 0.5 else voting.count { it.score * dir > 0 }.toDouble() / voting.size
        val confidence = ((0.6 * agree + 0.4 * min(1.0, abs(finalS) / 60)) * 100).roundToInt()
        val mixed = d1 * h4 < 0 && abs(d1) > 20 && abs(h4) > 20

        // ---------- 3) Score 1-5 with hard consistency rules ----------
        var score = when { finalS >= 50 -> 5; finalS >= 30 -> 4; finalS >= 8 -> 3; finalS >= -15 -> 2; else -> 1 }
        val warnings = mutableListOf<String>()
        fun cap(m: Int, why: String) { if (score > m) { score = m; warnings.add(why) } }
        if (d1 < -25) cap(2, "Daily trend is bearish: no long setup against the major trend")
        if (mixed) cap(3, "Mixed signals: 1D and 4H disagree strongly")
        if (!isBtc && regime.name == "Bearish") cap(3, "BTC is bearish: altcoin longs carry extra risk")
        if (agree < 0.55) cap(3, "Low agreement between analysis schools")
        if (agree < 0.70) cap(4, "Agreement between schools is not strong enough for a 5/5")
        if (tk.quoteVolume < 300_000) cap(1, "Very low liquidity (24h volume under 300K USDT)")
        else if (tk.quoteVolume < 2_000_000) cap(2, "Low liquidity (24h volume under 2M USDT)")
        val rsi1d = Ind.rsi(cd.map { it.c }).last()
        if (rsi1d > 75 && score >= 3) warnings.add(f("Daily RSI %.0f is overbought: avoid chasing, wait for pullbacks", rsi1d))
        val label = when (score) {
            5 -> "Excellent setup"; 4 -> "Good setup"; 3 -> "Neutral: wait for entry zones"
            2 -> "Weak: high risk, better to wait"; else -> "AVOID this coin for now"
        }

        // ---------- Reasons ----------
        val ranked = listOf("4H" to tfs[1], "1D" to tfs[2]).flatMap { (n, t) -> t.schools.map { Triple(n, it, it.score * it.weight) } }
        val reasons = mutableListOf<String>()
        reasons.add("Market regime ${regime.name}: ${regime.notes.first()}")
        ranked.filter { it.third * dir > 0 }.sortedByDescending { abs(it.third) }.take(3).forEach { reasons.add("${it.first} ${it.second.name}: ${it.second.note}") }
        ranked.filter { it.third * dir < 0 }.sortedByDescending { abs(it.third) }.take(1).forEach { reasons.add("Against: ${it.first} ${it.second.name}: ${it.second.note}") }

        val base = Report(sym, price, tk.changePct, tk.quoteVolume, regime, score, label, confidence, finalS, tfs, emptyList(), emptyList(), null, null, null, reasons, warnings)
        if (score <= 2) return@coroutineScope base

        // ---------- 4) Entry zones (confluence clustering) ----------
        val atr4 = Ind.atr(c4)
        val entries = buildEntries(price, c4, cd, atr4)
        val avgEntry = entries.map { (it.low + it.high) / 2 }.average()
        val stop = entries.minOf { it.low } - 0.8 * atr4

        // ---------- 5) Targets (+10% / +50% / +100% only if structure supports them) ----------
        val targets = buildTargets(avgEntry, c4, cd, score, regime.name != "Bearish", warnings)
        val risk = avgEntry - stop
        val rr1 = if (risk > 0 && targets.isNotEmpty()) (targets.first().price - avgEntry) / risk else null
        val rrF = if (risk > 0 && targets.isNotEmpty()) (targets.last().price - avgEntry) / risk else null
        base.copy(entries = entries, targets = targets, stop = stop, rrFirst = rr1, rrFinal = rrF)
    }

    private fun buildEntries(price: Double, c4: List<Candle>, cd: List<Candle>, atr4: Double): List<Zone> {
        val out = ArrayList<Lvl>()
        for ((nm, cs) in listOf("4H" to c4, "1D" to cd)) {
            Ind.swings(cs).filter { !it.high }.takeLast(8).forEach { out.add(Lvl(it.p, it.p, "$nm swing low")) }
            val m = Smc.of(cs)
            m.demand.takeLast(3).forEach { out.add(Lvl(it[0], it[1], "$nm order block")) }
            m.fvgBull.takeLast(2).forEach { out.add(Lvl(it[0], it[1], "$nm fair value gap")) }
            val e = Ind.ema(cs.map { it.c }, 50).last(); out.add(Lvl(e, e, "$nm EMA50"))
            val e2 = Ind.ema(cs.map { it.c }, 200).last(); out.add(Lvl(e2, e2, "$nm EMA200"))
            val w = cs.takeLast(if (nm == "4H") 150 else 200)
            val hi = w.maxOf { it.h }; val lo = w.minOf { it.l }
            if (w.indexOfFirst { it.h == hi } > w.indexOfFirst { it.l == lo }) {
                for (r in listOf(0.5, 0.618, 0.786)) { val p = hi - (hi - lo) * r; out.add(Lvl(p, p, "$nm Fib $r")) }
            }
        }
        val k = Ind.kijun(c4); out.add(Lvl(k, k, "4H Kijun"))
        val cands = out.filter { it.lo < price && it.hi >= price * 0.82 }.map { Lvl(it.lo, min(it.hi, price), it.tag) }
        if (cands.isEmpty()) return listOf(Zone(price - 0.6 * atr4, price, 1, listOf("Current price area (no strong support nearby)")))
        val tol = max(0.8 * atr4, price * 0.006)
        val clusters = ArrayList<MutableList<Lvl>>()
        for (l in cands.sortedByDescending { it.hi }) {
            val cl = clusters.lastOrNull()
            if (cl != null && cl.minOf { it.lo } - l.hi <= tol && cl.maxOf { it.hi } - l.lo <= 3 * tol) cl.add(l) else clusters.add(mutableListOf(l))
        }
        val zones = clusters.map { cl ->
            var lo = cl.minOf { it.lo }; var hi = cl.maxOf { it.hi }
            if (hi - lo < 0.5 * atr4) { val m = (hi + lo) / 2; lo = m - 0.25 * atr4; hi = m + 0.25 * atr4 }
            val tags = cl.map { it.tag }.distinct()
            Zone(lo, min(hi, price), tags.size, tags.take(4))
        }
        return zones.sortedByDescending { it.confluence * 10 - (price - it.high) / price * 100 }.take(3).sortedByDescending { it.high }
    }

    private fun buildTargets(entry: Double, c4: List<Candle>, cd: List<Candle>, score: Int, regimeOk: Boolean, warnings: MutableList<String>): List<Target> {
        val res = ArrayList<Lvl>()
        Ind.swings(c4).filter { it.high }.takeLast(15).forEach { res.add(Lvl(it.p, it.p, "4H resistance")) }
        Ind.swings(cd).filter { it.high }.takeLast(25).forEach { res.add(Lvl(it.p, it.p, "1D resistance")) }
        Smc.of(cd).supply.takeLast(3).forEach { res.add(Lvl(it[0], it[1], "1D supply zone")) }
        val hi500 = cd.maxOf { it.h }; res.add(Lvl(hi500, hi500, "500-day high"))
        val w = cd.takeLast(250); val hi = w.maxOf { it.h }; val lo = w.minOf { it.l }
        for (e in listOf(1.0, 1.272, 1.618, 2.0, 2.618)) { val p = lo + (hi - lo) * e; res.add(Lvl(p, p, "1D Fib ext $e")) }

        fun pick(minR: Double, maxR: Double, center: Double): Lvl? {
            val inBand = res.filter { it.lo / entry in minR..maxR }
            return inBand.maxWithOrNull(compareBy<Lvl>({ c -> inBand.count { abs(it.lo - c.lo) / c.lo < 0.03 } }, { -abs(it.lo / entry - center) }))
        }
        fun tp(i: Int, l: Lvl): Target { val p = l.lo * 0.99; return Target("TP$i", p, (p / entry - 1) * 100, l.tag) }
        val out = ArrayList<Target>()
        out.add(pick(1.06, 1.22, 1.10)?.let { tp(1, it) } ?: Target("TP1", entry * 1.10, 10.0, "Projected (no structure level in range)"))
        val t2 = pick(1.30, 1.80, 1.50)
        if (t2 != null) out.add(tp(2, t2)) else if (score >= 4) out.add(Target("TP2", entry * 1.5, 50.0, "Projected (strong trend, no resistance in range)"))
        val t3 = pick(1.81, 2.60, 2.0)
        if (t3 != null && score >= 4 && regimeOk && out.size == 2) out.add(tp(3, t3))
        else warnings.add("+100% target is not supported by the current analysis")
        return out
    }
}
