package com.spotscope.app

import kotlin.math.*

data class Candle(val t: Long, val o: Double, val h: Double, val l: Double, val c: Double, val v: Double)
data class SchoolResult(val name: String, val score: Double, val note: String, val weight: Double)
data class TfResult(val tf: String, val weight: Double, val schools: List<SchoolResult>, val total: Double)
data class Zone(val low: Double, val high: Double, val confluence: Int, val why: List<String>)
data class Target(val label: String, val price: Double, val gainPct: Double, val basis: String)
data class Regime(val name: String, val score: Double, val notes: List<String>)
data class Report(
    val symbol: String, val price: Double, val change24h: Double, val quoteVolume: Double,
    val regime: Regime, val score: Int, val label: String, val confidence: Int, val rawScore: Double,
    val tfs: List<TfResult>, val entries: List<Zone>, val targets: List<Target>,
    val stop: Double?, val rrFirst: Double?, val rrFinal: Double?,
    val reasons: List<String>, val warnings: List<String>
)
class SymbolNotFound : Exception()

fun clamp(x: Double, lo: Double = -100.0, hi: Double = 100.0) = max(lo, min(hi, x))

data class Swing(val i: Int, val p: Double, val high: Boolean)

object Ind {
    fun ema(x: List<Double>, n: Int): List<Double> {
        if (x.isEmpty()) return emptyList()
        val k = 2.0 / (n + 1)
        val out = ArrayList<Double>(x.size)
        var prev = x[0]; out.add(prev)
        for (i in 1 until x.size) { prev = x[i] * k + prev * (1 - k); out.add(prev) }
        return out
    }

    fun rsi(c: List<Double>, n: Int = 14): List<Double> {
        val out = MutableList(c.size) { 50.0 }
        if (c.size <= n) return out
        var g = 0.0; var l = 0.0
        for (i in 1..n) { val d = c[i] - c[i - 1]; if (d >= 0) g += d else l -= d }
        var ag = g / n; var al = l / n
        out[n] = if (al == 0.0) 100.0 else 100 - 100 / (1 + ag / al)
        for (i in n + 1 until c.size) {
            val d = c[i] - c[i - 1]
            ag = (ag * (n - 1) + max(d, 0.0)) / n
            al = (al * (n - 1) + max(-d, 0.0)) / n
            out[i] = if (al == 0.0) 100.0 else 100 - 100 / (1 + ag / al)
        }
        return out
    }

    fun atr(cs: List<Candle>, n: Int = 14): Double {
        if (cs.size < 2) return 0.0
        val tr = (1 until cs.size).map { i -> max(cs[i].h - cs[i].l, max(abs(cs[i].h - cs[i - 1].c), abs(cs[i].l - cs[i - 1].c))) }
        var a = tr.take(n).average()
        for (i in n until tr.size) a = (a * (n - 1) + tr[i]) / n
        return a
    }

    fun macdHist(c: List<Double>): List<Double> {
        val e12 = ema(c, 12); val e26 = ema(c, 26)
        val m = c.indices.map { e12[it] - e26[it] }
        val s = ema(m, 9)
        return m.indices.map { m[it] - s[it] }
    }

    fun obv(cs: List<Candle>): List<Double> {
        val o = ArrayList<Double>(cs.size); var s = 0.0; o.add(0.0)
        for (i in 1 until cs.size) {
            s += when { cs[i].c > cs[i - 1].c -> cs[i].v; cs[i].c < cs[i - 1].c -> -cs[i].v; else -> 0.0 }
            o.add(s)
        }
        return o
    }

    fun swings(cs: List<Candle>, k: Int = 3): List<Swing> {
        val out = ArrayList<Swing>()
        for (i in k until cs.size - k) {
            var isH = true; var isL = true
            for (j in 1..k) {
                if (cs[i].h <= cs[i - j].h || cs[i].h < cs[i + j].h) isH = false
                if (cs[i].l >= cs[i - j].l || cs[i].l > cs[i + j].l) isL = false
            }
            if (isH) out.add(Swing(i, cs[i].h, true))
            if (isL) out.add(Swing(i, cs[i].l, false))
        }
        return out
    }

    fun kijun(cs: List<Candle>): Double {
        val w = cs.takeLast(26)
        return (w.maxOf { it.h } + w.minOf { it.l }) / 2
    }
}

class Smc(val demand: List<DoubleArray>, val supply: List<DoubleArray>, val fvgBull: List<DoubleArray>, val fvgBear: List<DoubleArray>) {
    companion object {
        fun of(cs: List<Candle>): Smc {
            val n = cs.size
            val atr = Ind.atr(cs)
            val dem = ArrayList<DoubleArray>(); val sup = ArrayList<DoubleArray>()
            for (i in max(1, n - 150) until n - 3) {
                val c = cs[i]
                val nh = (i + 1..i + 3).maxOf { cs[it].h }
                val nl = (i + 1..i + 3).minOf { cs[it].l }
                if (c.c < c.o && nh - c.h > 1.5 * atr && (i + 1 until n).none { cs[it].c < c.l }) dem.add(doubleArrayOf(c.l, c.o))
                if (c.c > c.o && c.l - nl > 1.5 * atr && (i + 1 until n).none { cs[it].c > c.h }) sup.add(doubleArrayOf(c.o, c.h))
            }
            val fb = ArrayList<DoubleArray>(); val fs = ArrayList<DoubleArray>()
            for (i in max(2, n - 150) until n) {
                val a = cs[i - 2]; val b = cs[i]
                if (a.h < b.l && (i + 1 until n).none { cs[it].l <= a.h }) fb.add(doubleArrayOf(a.h, b.l))
                if (a.l > b.h && (i + 1 until n).none { cs[it].h >= a.l }) fs.add(doubleArrayOf(b.h, a.l))
            }
            return Smc(dem.takeLast(4), sup.takeLast(4), fb.takeLast(3), fs.takeLast(3))
        }
    }
}
