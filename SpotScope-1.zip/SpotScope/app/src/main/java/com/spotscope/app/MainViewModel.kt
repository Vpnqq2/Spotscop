package com.spotscope.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

sealed interface UiState {
    object Idle : UiState
    object Loading : UiState
    data class Error(val msg: String) : UiState
    data class Done(val r: Report) : UiState
}

class MainViewModel : ViewModel() {
    var state by mutableStateOf<UiState>(UiState.Idle)
        private set

    fun analyze(q: String) {
        if (state is UiState.Loading) return
        viewModelScope.launch {
            state = UiState.Loading
            state = try { UiState.Done(Analyzer.analyze(q)) }
            catch (e: SymbolNotFound) { UiState.Error("Coin not found on Binance Spot (USDT pair). Check the name.") }
            catch (e: Exception) { UiState.Error(e.message ?: "Network error. Try again.") }
        }
    }
}
