package com.spotscope.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(val sym: String, val score: Int, val price: Double, val time: Long, val strength: Int = 0)

object Store {
    private lateinit var sp: SharedPreferences
    val favorites = mutableStateListOf<String>()
    val history = mutableStateListOf<HistoryItem>()
    var defaultTf by mutableStateOf("4h")
    var lang by mutableStateOf("en")
    var notif by mutableStateOf(true)
    var accepted by mutableStateOf(false)

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("spotscope", Context.MODE_PRIVATE)
        favorites.clear(); favorites.addAll((sp.getString("fav", "") ?: "").split(",").filter { it.isNotBlank() })
        history.clear()
        runCatching {
            val a = JSONArray(sp.getString("hist", "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); history.add(HistoryItem(o.getString("s"), o.getInt("c"), o.getDouble("p"), o.getLong("t"), o.optInt("r", strengthOf(o.getInt("c"), 50)))) }
        }
        defaultTf = sp.getString("tf", "4h") ?: "4h"
        lang = sp.getString("lang", "en") ?: "en"
        notif = sp.getBoolean("notif", true)
        accepted = sp.getBoolean("accepted", false)
    }

    fun toggleFav(sym: String) {
        if (!favorites.remove(sym)) favorites.add(0, sym)
        sp.edit().putString("fav", favorites.joinToString(",")).apply()
    }
    fun clearFavorites() { favorites.clear(); sp.edit().putString("fav", "").apply() }
    fun addHistory(i: HistoryItem) { history.add(0, i); while (history.size > 100) history.removeAt(history.size - 1); saveHist() }
    fun clearHistory() { history.clear(); saveHist() }
    fun setTf(tf: String) { defaultTf = tf; sp.edit().putString("tf", tf).apply() }
    fun changeLang(l: String) { lang = l; sp.edit().putString("lang", l).apply() }
    fun acceptTerms() { accepted = true; sp.edit().putBoolean("accepted", true).apply() }
    fun changeNotif(b: Boolean) { notif = b; sp.edit().putBoolean("notif", b).apply() }
    private fun saveHist() {
        val a = JSONArray()
        history.forEach { a.put(JSONObject().put("s", it.sym).put("c", it.score).put("p", it.price).put("t", it.time).put("r", it.strength)) }
        sp.edit().putString("hist", a.toString()).apply()
    }
}
