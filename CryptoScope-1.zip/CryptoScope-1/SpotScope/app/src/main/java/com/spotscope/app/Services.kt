package com.spotscope.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/** AdMob: interstitial on every Nth search + rewarded video for the analysis gate. Uses Google TEST ids until you change res/values/ads.xml. */
object Ads {
    const val INTERSTITIAL_EVERY_N_SEARCHES = 5
    private var interstitial: InterstitialAd? = null
    private var rewarded: RewardedAd? = null
    private var started = false
    private var inited = false

    /** Shows the EU/UK consent form when required (UMP), then initializes ads. */
    fun start(activity: Activity) {
        if (started) return
        started = true
        val ci = UserMessagingPlatform.getConsentInformation(activity)
        ci.requestConsentInfoUpdate(
            activity, ConsentRequestParameters.Builder().build(),
            { UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ -> if (ci.canRequestAds()) initAds(activity) } },
            { _ -> if (ci.canRequestAds()) initAds(activity) }
        )
        if (ci.canRequestAds()) initAds(activity)
    }

    private fun initAds(ctx: Context) {
        if (inited) return
        inited = true
        MobileAds.initialize(ctx) {}
        loadInterstitial(ctx); loadRewarded(ctx)
    }

    private fun loadInterstitial(ctx: Context) {
        if (!inited) return
        InterstitialAd.load(ctx, ctx.getString(R.string.admob_interstitial_id), AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
            override fun onAdFailedToLoad(e: LoadAdError) { interstitial = null }
        })
    }

    private fun loadRewarded(ctx: Context) {
        if (!inited) return
        RewardedAd.load(ctx, ctx.getString(R.string.admob_rewarded_id), AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewarded = ad }
            override fun onAdFailedToLoad(e: LoadAdError) { rewarded = null }
        })
    }

    /** Shows the interstitial if one is ready, then calls onDone. Never blocks the user if no ad is available. */
    fun showInterstitial(activity: Activity, onDone: () -> Unit) {
        val ad = interstitial
        if (ad == null) { loadInterstitial(activity); onDone(); return }
        interstitial = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { loadInterstitial(activity); onDone() }
            override fun onAdFailedToShowFullScreenContent(e: AdError) { loadInterstitial(activity); onDone() }
        }
        ad.show(activity)
    }

    /** onReward runs only after the user earned the reward; onUnavailable if no video could be shown. */
    fun showRewarded(activity: Activity, onReward: () -> Unit, onUnavailable: () -> Unit) {
        val ad = rewarded
        if (ad == null) { loadRewarded(activity); onUnavailable(); return }
        rewarded = null
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { loadRewarded(activity); if (earned) onReward() }
            override fun onAdFailedToShowFullScreenContent(e: AdError) { loadRewarded(activity); onUnavailable() }
        }
        ad.show(activity) { earned = true }
    }
}

/** Firebase Analytics. Safe no-op when google-services.json is missing. */
object Analytics {
    private var fa: FirebaseAnalytics? = null

    fun init(ctx: Context) {
        fa = try { if (FirebaseApp.getApps(ctx).isNotEmpty()) FirebaseAnalytics.getInstance(ctx) else null } catch (e: Exception) { null }
    }

    fun log(name: String, vararg params: Pair<String, String>) {
        val b = Bundle()
        params.forEach { b.putString(it.first, it.second) }
        try { fa?.logEvent(name, b) } catch (e: Exception) { }
    }
}

/** Firebase Cloud Messaging: users subscribe to the "all" topic so you can send campaigns from the Firebase console. */
object Push {
    private const val TOPIC = "all"

    fun setEnabled(ctx: Context, on: Boolean) {
        try {
            if (FirebaseApp.getApps(ctx).isEmpty()) return
            val m = FirebaseMessaging.getInstance()
            if (on) m.subscribeToTopic(TOPIC) else m.unsubscribeFromTopic(TOPIC)
        } catch (e: Exception) { }
    }
}

object Notifier {
    const val CHANNEL = "spotscope_alerts"

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Market alerts", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, title: String, body: String) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        ensureChannel(ctx)
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(pi).build()
        NotificationManagerCompat.from(ctx).notify(System.currentTimeMillis().toInt(), n)
    }
}

/** Shows pushes that arrive while the app is open (background pushes are shown by the system). */
class SpotMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: "CryptoScope"
        val body = message.notification?.body ?: message.data["body"] ?: return
        Notifier.show(this, title, body)
    }
}
