package com.spotscope.app

import androidx.compose.runtime.mutableStateMapOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Coin logo URLs from the CoinGecko public API (symbol, lowercase -> image URL). Attribution: "Powered by CoinGecko". */
object CoinIcons {
    val urls = mutableStateMapOf<String, String>()
    private var started = false

    suspend fun load() {
        if (started) return
        started = true
        try {
            val txt = withContext(Dispatchers.IO) {
                val c = URL("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=1").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 12000
                c.setRequestProperty("User-Agent", "CryptoScope/1.0")
                if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
                c.inputStream.bufferedReader().use { it.readText() }
            }
            val a = JSONArray(txt)
            val m = HashMap<String, String>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val s = o.optString("symbol").lowercase()
                val img = o.optString("image")
                if (s.isNotEmpty() && img.startsWith("https://") && s !in m) m[s] = img   // highest market cap wins on duplicate symbols
            }
            urls.putAll(m)
        } catch (e: Exception) {
            started = false
        }
    }
}
