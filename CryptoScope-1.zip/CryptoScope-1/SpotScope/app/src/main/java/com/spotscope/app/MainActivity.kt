package com.spotscope.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        Store.init(applicationContext)
        Analytics.init(applicationContext)
        Notifier.ensureChannel(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = BgC, surface = CardC, onSurface = TextC, onBackground = TextC)) {
                CompositionLocalProvider(LocalTextStyle provides TextStyle(textAlign = TextAlign.Left)) { Box(Modifier.fillMaxSize().background(BgC).systemBarsPadding().imePadding()) { App() } }
            }
        }
    }
}

@Composable
fun App(vm: MainViewModel = viewModel()) {
    val activity = LocalContext.current as ComponentActivity
    var splash by rememberSaveable { mutableStateOf(true) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var sub by rememberSaveable { mutableStateOf("") }
    var gateSym by remember { mutableStateOf<String?>(null) }

    fun permMissing() = Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> Push.setEnabled(activity, granted && Store.notif) }
    fun applyNotif() {
        if (!Store.notif) Push.setEnabled(activity, false)
        else if (permMissing()) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else Push.setEnabled(activity, true)
    }

    LaunchedEffect(Unit) { CoinIcons.load() }
    LaunchedEffect(Unit) { delay(2200); splash = false }
    LaunchedEffect(Store.accepted) { if (Store.accepted) { Ads.start(activity); applyNotif() } }
    if (splash) { SplashScreen(); return }
    if (!Store.accepted) { DisclaimerScreen { Store.acceptTerms() }; return }

    fun proceed(sym: String) {
        Store.recordAnalysis()
        Analytics.log("analyze_coin", "symbol" to sym)
        vm.analyze(sym); tab = 2; sub = ""
    }
    /** Every analysis goes through here: after GATE_COUNT analyses in GATE_WINDOW_MS a rewarded video is required. */
    fun open(sym: String) {
        if (Store.gateNeeded()) { gateSym = sym; Analytics.log("ad_gate_shown") } else proceed(sym)
    }
    /** Search box: every Nth search shows an interstitial first. */
    fun search(sym: String) {
        val n = Store.countSearch()
        Analytics.log("search", "query" to sym)
        if (!Store.gateNeeded() && n % Ads.INTERSTITIAL_EVERY_N_SEARCHES == 0) Ads.showInterstitial(activity) { open(sym) } else open(sym)
    }
    BackHandler(enabled = sub != "" || tab != 0) { if (sub != "") sub = "" else tab = 0 }

    Column(Modifier.fillMaxSize().background(BgC)) {
        Box(Modifier.weight(1f)) {
            Crossfade(targetState = if (sub != "") sub else tab.toString(), animationSpec = tween(260), label = "page") { k ->
                when (k) {
                    "discover" -> DiscoverScreen({ sub = "" }) { open(it) }
                    "history" -> HistoryScreen({ sub = "" }) { open(it) }
                    "0" -> HomeScreen({ open(it) }, { search(it) }) { sub = "discover" }
                    "1" -> MarketsScreen({ open(it) }) { sub = "discover" }
                    "2" -> AnalyzeScreen(vm, { tab = 0 }) { search(it) }
                    "3" -> FavoritesScreen { open(it) }
                    else -> MoreScreen({ sub = it }) { on -> Store.changeNotif(on); applyNotif() }
                }
            }
        }
        BottomBar(if (sub == "discover") 1 else if (sub == "history") 4 else tab) { tab = it; sub = ""; Analytics.log("tab_open", "tab" to it.toString()) }
    }

    gateSym?.let { sym ->
        AdGateDialog(
            onWatch = {
                gateSym = null
                Analytics.log("rewarded_start")
                Ads.showRewarded(activity,
                    onReward = { Store.resetGate(); Analytics.log("rewarded_earned"); proceed(sym) },
                    onUnavailable = { proceed(sym) })
            },
            onDismiss = { gateSym = null }
        )
    }
}

@Composable
fun BottomBar(sel: Int, onSel: (Int) -> Unit) {
    val labels = listOf(tr("الرئيسية", "Home"), tr("الأسواق", "Markets"), tr("تحليل العملات", "Analyze"), tr("المفضلة", "Favorites"), tr("المزيد", "More"))
    Column(Modifier.fillMaxWidth().background(CardC)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(BorderC))
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            labels.forEachIndexed { i, label ->
                val c by animateColorAsState(if (sel == i) Gold else MutedC, label = "navColor")
                val sc by animateFloatAsState(if (sel == i) 1.18f else 1f, label = "navScale")
                Column(Modifier.weight(1f).clickable { onSel(i) }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(Modifier.graphicsLayer { scaleX = sc; scaleY = sc }) {
                        when (i) {
                            0 -> NavIcon("home", c)
                            1 -> NavIcon("markets", c)
                            2 -> NavIcon("analyze", c)
                            3 -> Icon(Icons.Filled.Star, contentDescription = label, tint = c, modifier = Modifier.size(22.dp))
                            else -> NavIcon("more", c)
                        }
                    }
                    Text(label, color = c, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center)
                }
            }
        }
    }
}
