package com.spotscope.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

@Composable
fun Screen(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
fun Title(t: String, onBack: (() -> Unit)? = null, trailing: @Composable (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) Text("‹", color = TextC, fontSize = 32.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 12.dp))
        Text(t, color = TextC, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing?.invoke()
    }
}

@Composable
fun SearchBox(onGo: (String) -> Unit, button: String = "Analyze") {
    var q by rememberSaveable { mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, modifier = Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(14.dp),
            placeholder = { Text("Search coin (BTC, ETH, AVAX...)", color = MutedC, fontSize = 13.sp) },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = BorderC, focusedTextColor = TextC, unfocusedTextColor = TextC, cursorColor = Gold, focusedContainerColor = CardC, unfocusedContainerColor = CardC),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { if (q.isNotBlank()) onGo(q) })
        )
        Button(onClick = { if (q.isNotBlank()) onGo(q) }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)) { Text(button, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun ScanStatus() {
    if (Scanner.running) Text("Scoring top coins… ${Scanner.done}/${Scanner.total}", color = MutedC, fontSize = 12.sp)
}

@Composable
fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(BgC), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("▂▄▆", color = Gold, fontSize = 54.sp, fontWeight = FontWeight.Black)
            Text("SpotScope", color = Gold, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
            Text("Smart Spot Analysis", color = TextC, fontSize = 15.sp)
            Text("Professional crypto spot analysis, no noise", color = MutedC, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ HOME
@Composable
fun HomeScreen(onOpen: (String) -> Unit, onDiscover: () -> Unit) {
    var ticks by remember { mutableStateOf<List<Tick>>(emptyList()) }
    var ov by remember { mutableStateOf<Overview?>(null) }
    var sparks by remember { mutableStateOf<Map<String, List<Double>>>(emptyMap()) }
    LaunchedEffect(Unit) { Scanner.ensure() }
    LaunchedEffect(Unit) { ticks = runCatching { MarketData.tickers() }.getOrDefault(emptyList()) }
    LaunchedEffect(Unit) { ov = runCatching { MarketData.overview() }.getOrNull() }
    LaunchedEffect(Unit) { sparks = listOf("BTCUSDT", "ETHUSDT").associateWith { runCatching { MarketData.spark(it) }.getOrDefault(emptyList()) } }
    Screen {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("▂▄▆ ", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text("SpotScope", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        }
        SearchBox(onOpen)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("BTCUSDT", "ETHUSDT").forEach { s ->
                val t = ticks.firstOrNull { it.sym == s }
                Panel(modifier = Modifier.weight(1f).clickable { onOpen(s) }) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Avatar(s, 28.dp); Text(baseOf(s), color = TextC, fontWeight = FontWeight.Bold) }
                    Text(t?.let { fmtPrice(it.last) } ?: "–", color = TextC, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(t?.let { fmtPct(it.change) } ?: "", color = if ((t?.change ?: 0.0) >= 0) GreenC else RedC, fontSize = 12.sp)
                    Sparkline(sparks[s] ?: emptyList(), if ((t?.change ?: 0.0) >= 0) GreenC else RedC, Modifier.fillMaxWidth().height(34.dp))
                }
            }
        }
        Panel("Market Overview") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Total Market Cap", color = MutedC, fontSize = 11.sp)
                    Text(ov?.totalCap?.let { fmtBig(it) } ?: "–", color = TextC, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    ov?.capChange?.takeIf { !it.isNaN() }?.let { Text(fmtPct(it), color = if (it >= 0) GreenC else RedC, fontSize = 12.sp) }
                }
                Column(Modifier.weight(1f)) {
                    Text("BTC Dominance", color = MutedC, fontSize = 11.sp)
                    Text(ov?.btcDom?.let { String.format(Locale.US, "%.1f%%", it) } ?: "–", color = TextC, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Top Coins", color = TextC, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
            Text("Discover ›", color = Gold, fontSize = 13.sp, modifier = Modifier.clickable(onClick = onDiscover))
        }
        ScanStatus()
        if (ticks.isEmpty()) Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
        ticks.sortedByDescending { it.quoteVol }.take(8).forEach { t -> CoinRow(t.sym, t.last, t.change, Scanner.items[t.sym]?.score) { onOpen(t.sym) } }
    }
}

// ------------------------------------------------------------------ MARKETS
@Composable
fun MarketsScreen(onOpen: (String) -> Unit, onDiscover: () -> Unit) {
    var reg by remember { mutableStateOf<Regime?>(null) }
    var ticks by remember { mutableStateOf<List<Tick>>(emptyList()) }
    var spark by remember { mutableStateOf<List<Double>>(emptyList()) }
    LaunchedEffect(Unit) { Scanner.ensure() }
    LaunchedEffect(Unit) { reg = runCatching { Analyzer.regime() }.getOrNull() }
    LaunchedEffect(Unit) {
        ticks = runCatching { MarketData.tickers() }.getOrDefault(emptyList())
        spark = runCatching { MarketData.spark("BTCUSDT") }.getOrDefault(emptyList())
    }
    val btc = ticks.firstOrNull { it.sym == "BTCUSDT" }
    val ranked = Scanner.items.values.filter { it.sym != "BTCUSDT" }.sortedWith(compareByDescending<ScanItem> { it.score }.thenByDescending { it.confidence })
    val movers = ticks.sortedByDescending { it.quoteVol }.take(60).sortedByDescending { it.change }
    Screen {
        Title("Market Analysis")
        Panel("Bitcoin Trend") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Avatar("BTCUSDT", 40.dp)
                Column(Modifier.weight(1f)) {
                    Text(btc?.let { fmtPrice(it.last) } ?: "–", color = TextC, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(btc?.let { fmtPct(it.change) } ?: "", color = if ((btc?.change ?: 0.0) >= 0) GreenC else RedC, fontSize = 12.sp)
                }
                Sparkline(spark, if ((btc?.change ?: 0.0) >= 0) GreenC else RedC, Modifier.width(110.dp).height(40.dp))
            }
        }
        val r = reg
        if (r == null) Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
        else Panel("Market State") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Ring(((r.score + 100) / 200).toFloat(), r.name, regimeColor(r.name), 104.dp, "regime")
                Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) { r.notes.forEach { Text("• $it", color = TextC, fontSize = 12.sp) } }
            }
        }
        ScanStatus()
        Panel("Strongest Alts") {
            if (ranked.isEmpty()) Text("Scoring coins…", color = MutedC, fontSize = 12.sp)
            ranked.take(5).forEach { MiniRow(it, onOpen) }
        }
        Panel("Weakest Alts") { ranked.takeLast(3).reversed().forEach { MiniRow(it, onOpen) } }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Panel("Top Gainers 24h", Modifier.weight(1f)) { movers.take(3).forEach { Mover(it, onOpen) } }
            Panel("Top Losers 24h", Modifier.weight(1f)) { movers.takeLast(3).reversed().forEach { Mover(it, onOpen) } }
        }
        r?.let {
            val tip = when (it.name) {
                "Bullish" -> "Conditions favour spot entries on pullbacks into the entry zones. Prefer coins scoring 4 or 5."
                "Bearish" -> "BTC is weak, so altcoins carry extra risk. Reduce size, or wait for a better market."
                else -> "Market is undecided. Be selective and only take setups scoring 4 or higher."
            }
            Panel("Trading Note") { Text(tip, color = TextC, fontSize = 13.sp) }
        }
        Text("Browse all scored coins ›", color = Gold, modifier = Modifier.clickable(onClick = onDiscover))
    }
}

@Composable
fun MiniRow(s: ScanItem, onOpen: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onOpen(s.sym) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Avatar(s.sym, 28.dp)
        Text(baseOf(s.sym), color = TextC, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(fmtPct(s.change), color = if (s.change >= 0) GreenC else RedC, fontSize = 12.sp)
        ScoreRing(s.score, 30.dp)
    }
}

@Composable
fun Mover(t: Tick, onOpen: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onOpen(t.sym) }, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(baseOf(t.sym), color = TextC, fontSize = 13.sp)
        Text(fmtPct(t.change), color = if (t.change >= 0) GreenC else RedC, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ------------------------------------------------------------------ DISCOVER
@Composable
fun DiscoverScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    var f by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { Scanner.ensure() }
    val all = Scanner.items.values.sortedWith(compareByDescending<ScanItem> { it.score }.thenByDescending { it.confidence })
    val list = when (f) { 1 -> all.filter { it.score >= 4 }; 2 -> all.filter { it.score == 3 }; 3 -> all.filter { it.score <= 2 }; else -> all }
    Screen {
        Title("Discover Coins", onBack) { Text("Refresh", color = Gold, fontSize = 13.sp, modifier = Modifier.clickable { Scanner.ensure(true) }) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("All", "Strong", "Neutral", "Avoid").forEachIndexed { i, t -> Chip(t, f == i) { f = i } } }
        ScanStatus()
        if (list.isEmpty() && !Scanner.running) Text("No coins in this group right now.", color = MutedC)
        list.forEach { CoinRow(it.sym, it.price, it.change, it.score) { onOpen(it.sym) } }
    }
}

// ------------------------------------------------------------------ FAVORITES / HISTORY / MORE / SETTINGS
@Composable
fun FavoritesScreen(onOpen: (String) -> Unit) {
    var ticks by remember { mutableStateOf<List<Tick>>(emptyList()) }
    LaunchedEffect(Unit) { ticks = runCatching { MarketData.tickers() }.getOrDefault(emptyList()); Scanner.ensure(Store.favorites.any { it !in Scanner.items }) }
    Screen {
        Title("Favorites")
        if (Store.favorites.isEmpty()) Text("Tap the star on a coin's analysis page to add it here.", color = MutedC)
        Store.favorites.toList().forEach { s ->
            val t = ticks.firstOrNull { it.sym == s }
            CoinRow(s, t?.last, t?.change, Scanner.items[s]?.score) { onOpen(s) }
        }
    }
}

@Composable
fun HistoryScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    var f by remember { mutableStateOf(0) }
    val fmt = remember { SimpleDateFormat("MMM d, HH:mm", Locale.US) }
    val list = Store.history.filter { when (f) { 1 -> it.score >= 4; 2 -> it.score == 3; 3 -> it.score <= 2; else -> true } }
    Screen {
        Title("Analysis History", onBack)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("All", "Strong", "Neutral", "Avoid").forEachIndexed { i, t -> Chip(t, f == i) { f = i } } }
        if (list.isEmpty()) Text("No analyses yet.", color = MutedC)
        list.forEach { h ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(14.dp)).clickable { onOpen(h.sym) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Avatar(h.sym)
                Column(Modifier.weight(1f)) {
                    Text(baseOf(h.sym), color = TextC, fontWeight = FontWeight.Bold)
                    Text("${fmtPrice(h.price)} · ${fmt.format(Date(h.time))}", color = MutedC, fontSize = 11.sp)
                }
                Text(verdict(h.score), color = scoreColor(h.score), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                ScoreRing(h.score, 36.dp)
            }
        }
    }
}

@Composable
fun MoreScreen(go: (String) -> Unit) {
    Screen {
        Title("More")
        listOf("discover" to "Discover Coins", "history" to "Analysis History", "settings" to "Settings").forEach { (k, t) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardC).border(1.dp, BorderC, RoundedCornerShape(14.dp)).clickable { go(k) }.padding(16.dp)) {
                Text(t, color = TextC, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("›", color = MutedC, fontSize = 20.sp)
            }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    Screen {
        Title("Settings", onBack)
        Panel("Default chart timeframe") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { TFS.forEach { (k, l) -> Chip(l, Store.defaultTf == k) { Store.setTf(k) } } }
        }
        Panel("Data") {
            OutlinedButton(onClick = { Store.clearHistory() }) { Text("Clear analysis history", color = TextC) }
            OutlinedButton(onClick = { Store.clearFavorites() }) { Text("Clear favorites", color = TextC) }
        }
        Panel("About") {
            Text("SpotScope v1.0", color = TextC, fontWeight = FontWeight.SemiBold)
            Text("Market data: Binance public spot API. Market cap and BTC dominance: CoinGecko.", color = MutedC, fontSize = 12.sp)
            Text("Not financial advice. No analysis is 100% accurate. Always use a stop loss and never risk more than you can afford to lose.", color = MutedC, fontSize = 12.sp)
        }
    }
}

val TFS = listOf("15m" to "15m", "1h" to "1H", "4h" to "4H", "1d" to "1D", "1w" to "1W")

// ------------------------------------------------------------------ ANALYZE
@Composable
fun AnalyzeScreen(vm: MainViewModel, onSearch: (String) -> Unit) {
    val st = vm.state
    Screen {
        Title("Coin Analysis")
        SearchBox(onSearch)
        when (st) {
            UiState.Idle -> {
                Text("Type a coin to get its score (1-5), entry zones, targets and stop loss.", color = MutedC)
                if (Store.history.isNotEmpty()) {
                    Text("Recent", color = TextC, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Store.history.map { it.sym }.distinct().take(4).forEach { Chip(baseOf(it), false) { onSearch(it) } } }
                }
            }
            UiState.Loading -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
            is UiState.Error -> Panel { Text(st.msg, color = RedC) }
            is UiState.Done -> ReportView(st.r, vm)
        }
        Text("Not financial advice. No analysis is 100% accurate. Always use a stop loss.", color = MutedC, fontSize = 11.sp)
    }
}

@Composable
fun ReportView(r: Report, vm: MainViewModel) {
    val col = scoreColor(r.score)
    val fav = r.symbol in Store.favorites
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Avatar(r.symbol, 44.dp)
            Column(Modifier.weight(1f)) {
                Text(baseOf(r.symbol), color = TextC, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(fmtPrice(r.price), color = TextC, fontWeight = FontWeight.SemiBold)
                Text("${fmtPct(r.change24h)} (24h)", color = if (r.change24h >= 0) GreenC else RedC, fontSize = 12.sp)
            }
            Icon(Icons.Filled.Star, contentDescription = "Favorite", tint = if (fav) Gold else MutedC, modifier = Modifier.size(28.dp).clickable { Store.toggleFav(r.symbol) })
            ScoreRing(r.score, 60.dp)
        }
    }
    if (r.score <= 1) Banner("AVOID THIS COIN. Do not enter now.", RedC, r.warnings)
    else if (r.score == 2) Banner("Weak setup: no entry zones. Wait for a better structure.", OrangeC, r.warnings)

    // Chart
    var ind by rememberSaveable { mutableStateOf("RSI") }
    Panel {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { TFS.forEach { (k, l) -> Chip(l, vm.chartTf == k) { vm.loadChart(r.symbol, k) } } }
        val cs = vm.chart
        if (cs.size < 30) Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
        else {
            val n = min(70, cs.size)
            val closes = cs.map { it.c }
            val e20 = Ind.ema(closes, 20).takeLast(n); val e50 = Ind.ema(closes, 50).takeLast(n)
            val lines = listOfNotNull(r.stop?.let { it to RedC }) + r.targets.map { it.price to Gold }
            CandleChart(cs.takeLast(n), e20, e50, r.entries, lines, Modifier.fillMaxWidth().height(230.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("— EMA20", color = Gold, fontSize = 10.sp); Text("— EMA50", color = BlueC, fontSize = 10.sp)
                if (r.entries.isNotEmpty()) { Text("▮ Entry", color = GreenC, fontSize = 10.sp); Text("- - TP", color = Gold, fontSize = 10.sp); Text("- - Stop", color = RedC, fontSize = 10.sp) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("RSI", "MACD", "Volume").forEach { Chip(it, ind == it) { ind = it } } }
            IndicatorPanel(ind, cs, n, Modifier.fillMaxWidth().height(80.dp))
        }
    }

    Panel("Analysis Summary") {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Ring(r.confidence / 100f, "${r.confidence}%", col, 84.dp, "confidence")
            Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) {
                Text(r.label, color = col, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text("Score ${r.score}/5 · ${"★".repeat(r.score)}${"☆".repeat(5 - r.score)}", color = MutedC, fontSize = 12.sp)
                Text("Market: ${r.regime.name}", color = regimeColor(r.regime.name), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }

    if (r.entries.isNotEmpty()) {
        Panel("Entry Zones (scale in, best first)") {
            r.entries.forEachIndexed { i, z ->
                Column {
                    Text("E${i + 1}:  ${fmtPrice(z.low)} – ${fmtPrice(z.high)}", color = GreenC, fontWeight = FontWeight.Bold)
                    Text("Confluence ${z.confluence}: ${z.why.joinToString(", ")}", color = MutedC, fontSize = 12.sp)
                }
            }
        }
        Panel("Targets") {
            r.targets.forEach {
                Column {
                    Text("${it.label}:  ${fmtPrice(it.price)}   (${String.format(Locale.US, "%+.1f%%", it.gainPct)})", color = Gold, fontWeight = FontWeight.Bold)
                    Text(it.basis, color = MutedC, fontSize = 12.sp)
                }
            }
        }
        Panel("Risk") {
            r.stop?.let { Text("Stop loss: ${fmtPrice(it)}  (close below invalidates the setup)", color = RedC, fontWeight = FontWeight.Bold) }
            r.rrFirst?.let { Text(String.format(Locale.US, "R/R to TP1: %.2f   |   to final target: %.2f", it, r.rrFinal ?: it), color = TextC, fontSize = 13.sp) }
        }
    }

    Panel("Key Levels") {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) { Text("Resistance", color = RedC, fontWeight = FontWeight.Bold, fontSize = 13.sp); r.resistances.forEach { Text(fmtPrice(it), color = TextC, fontSize = 13.sp) }; if (r.resistances.isEmpty()) Text("None above", color = MutedC, fontSize = 12.sp) }
            Column(Modifier.weight(1f)) { Text("Support", color = GreenC, fontWeight = FontWeight.Bold, fontSize = 13.sp); r.supports.forEach { Text(fmtPrice(it), color = TextC, fontSize = 13.sp) }; if (r.supports.isEmpty()) Text("None below", color = MutedC, fontSize = 12.sp) }
        }
    }

    Panel("Why this score") { r.reasons.forEach { Text("• $it", color = TextC, fontSize = 13.sp) } }
    if (r.warnings.isNotEmpty() && r.score >= 3) Panel("Warnings") { r.warnings.forEach { Text("• $it", color = OrangeC, fontSize = 13.sp) } }
    Panel("Market Regime: ${r.regime.name}") { r.regime.notes.forEach { Text("• $it", color = MutedC, fontSize = 12.sp) } }

    var open by rememberSaveable { mutableStateOf(false) }
    Panel("Breakdown by school") {
        Text(if (open) "Hide details" else "Show details", color = Gold, modifier = Modifier.clickable { open = !open })
        if (open) r.tfs.forEach { t ->
            Text(String.format(Locale.US, "%s  (weight %.0f%%)  total %+.0f", t.tf.uppercase(), t.weight * 100, t.total), color = signColor(t.total), fontWeight = FontWeight.Bold)
            t.schools.forEach { s ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.name, color = TextC, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(String.format(Locale.US, "%+.0f", s.score), color = signColor(s.score), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Text(s.note, color = MutedC, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun Banner(title: String, color: Color, why: List<String>) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.16f)).border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(14.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = color, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        why.forEach { Text("• $it", color = TextC, fontSize = 13.sp) }
    }
}
